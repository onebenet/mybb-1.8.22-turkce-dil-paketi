﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

// Help Section 1
$l['s1_name'] = "Kullanıcı Bakımı Ve Forum Kullanımı";
$l['s1_desc'] = "Forum Hesabı Kullanımı İçin Basit ve Temel Kılavuzlar.";

// Help Section 2
$l['s2_name'] = "Konu Ve Yorum Gönderimi";
$l['s2_desc'] = "Konu Gönderme, Cevap Yazma, Mykod'lar Ve Temel Olarak Forum Kullanım Kılavuzu.";

