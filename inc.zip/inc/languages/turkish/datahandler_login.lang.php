﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['logindata_invalidpwordusername'] = "Geçersiz bir kullanıcı adı veya şifre girdiniz.<br /><br />Eğer şifrenizi unuttuysanız, <a rel=\"nofollow\" href=\"member.php?action=lostpw\">Buraya</a> tıklayıp yeni bir şifre talebinde bulunabilirsiniz.";
$l['logindata_invalidpwordusernameemail'] = "Geçersiz bir e-posta veya şifre girdiniz.<br /><br />Eğer şifrenizi unuttuysanız, <a rel=\"nofollow\" href=\"member.php?action=lostpw\">Buraya</a> tıklayıp yeni bir şifre talebinde bulunabilirsiniz.";
$l['logindata_invalidpwordusernamecombo'] = "Geçersiz bir kullanıcı adı, şifre veya e-posta adresi girdiniz.<br /><br />Eğer şifrenizi unuttuysanız, <a rel=\"nofollow\" href=\"member.php?action=lostpw\">Buraya</a> tıklayıp yeni bir şifre talebinde bulunabilirsiniz.";

$l['logindata_regimageinvalid'] = "Girmiş olduğunuz resim doğrulama kodu yanlış. Lütfen kodu resimde göründüğü gibi giriniz. (Büyük / Küçük Harf Duyarlıdır)";
$l['logindata_regimagerequired'] = "Lütfen sol tarafta görmüş olduğunuz resim üzerindeki harf ve rakamlardan oluşan Güvenlik Kodunu, aşağıdaki metin kutusuna giriniz.";
