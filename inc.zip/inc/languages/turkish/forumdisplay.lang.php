﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['post_thread'] = "Yeni Konu";
$l['moderated_by'] = "Bölüm Yöneticileri:";
$l['nothreads'] = "Üzgünüz, aradığınız içerik belirtilen Tarih ve Zaman aralığında, bu forumda bulunamadı. Veya forum yöneticileri tarafından silinmiş yada başka bir bölüme taşınmış olabilir.";
$l['nopermission'] = "Üzgünüz, fakat bu forumdaki konuları görüntülemek için izniniz yok.";
$l['search_forum'] = "Bu Forumda Ara:";
$l['thread'] = "Konu";
$l['author'] = "Konuyu Açan";
$l['replies'] = "Yorumlar";
$l['views'] = "Okunma";
$l['lastpost'] = "Son Yorum";
$l['rating'] = "Oyla";
$l['prefix'] = "Ön Ek:";
$l['prefix_all'] = "Ön Ek: Rastgele/Yok";
$l['prefix_any'] = "Ön Ek: Rastgele Ekle";
$l['prefix_none'] = "Ön Ek: Hayır Ekleme";
$l['markforum_read'] = "Bu Forumu Okundu Say";
$l['subscribe_forum'] = "Bu Forumu Takip Et";
$l['unsubscribe_forum'] = "Bu Forumu Takip Etmeyi Bırak";
$l['clear_stored_password'] = "Gizli Forum Şifresini İptal Et";
$l['sort_by_subject'] = "Konu Başlığına Göre Listele";
$l['sort_by_lastpost'] = "Son Yoruma Göre Listele";
$l['sort_by_starter'] = "Konuyu Başlatana Göre Listele";
$l['sort_by_started'] = "Konu Açılış Tarihine Göre Listele";
$l['sort_by_rating'] = "Oylamaya Göre Listele";
$l['sort_by_replies'] = "Yorum Sayısına Göre Listele";
$l['sort_by_views'] = "Okunma Sayısına Göre Listele";
$l['sort_order_asc'] = "Listeleme: Artan";
$l['sort_order_desc'] = "Listeleme: Azalan";
$l['datelimit_1day'] = "Bugünkü Konuları Göster";
$l['datelimit_5days'] = "Son 5 Günlük Konuları Göster";
$l['datelimit_10days'] = "Son 10 Günlük Konuları Göster";
$l['datelimit_20days'] = "Son 20 Günlük Konuları Göster";
$l['datelimit_50days'] = "Son 50 Günlük Konuları Göster";
$l['datelimit_75days'] = "Son 75 Günlük Konuları Göster";
$l['datelimit_100days'] = "Son 100 Günlük Konuları Göster";
$l['datelimit_lastyear'] = "1 Yıllık Konular";
$l['datelimit_beginning'] = "Tüm Konuları Göster";
$l['new_thread'] = "Yeni Yorum Var";
$l['new_hot_thread'] = "Sıcak Konu (Yeni Yorum Var)";
$l['posts_by_you'] = "Sizin Yorumunuzu İçerir";
$l['no_new_thread'] = "Yeni Yorum Yok";
$l['hot_thread'] = "Sıcak Konu (Yeni Yorum Yok)";
$l['locked_thread'] = "Konu Kapalı";
$l['goto_first_unread'] = "İlk Okunmamış Yoruma Git";
$l['pages'] = "Sayfalar:";
$l['pages_last'] = "Son";
$l['users_browsing_forum'] = "Forumu Görüntüleyenler:";
$l['users_browsing_forum_guests'] = "{1} Ziyaretçi";
$l['users_browsing_forum_invis'] = "{1} Gizli Kullanıcı";
$l['delayed_moderation'] = "Gelişmiş Yönetime Git";
$l['inline_thread_moderation'] = "Konu Yönetimi:";
$l['close_threads'] = "Konuyu Kapat";
$l['open_threads'] = "Konuyu Aç";
$l['stick_threads'] = "Konuyu Üste Tuttur";
$l['unstick_threads'] = "Konuyu Üstten Kaldır";
$l['soft_delete_threads'] = "Konuyu Gizle/Geçici Sil";
$l['restore_threads'] = "Konuyu Göster/Geri Getir";
$l['delete_threads'] = "Konuyu Sil";
$l['move_threads'] = "Konuyu Taşı";
$l['approve_threads'] = "Konuyu Onayla";
$l['unapprove_threads'] = "Konu Onayını Kaldır";
$l['inline_go'] = "Git";
$l['clear'] = "İptal Et";
$l['sub_forums_in'] = "'{1}' - Kategorisindeki Alt Forumlar";
$l['forum_rules'] = "{1} - Kurallar";
$l['subforums'] = "Alt Forumlar:";
$l['asc'] = "+";
$l['desc'] = "-";
$l['forum_announcements'] = "Forum Duyuruları";
$l['sticky_threads'] = "Öne Çıkan Konular";
$l['normal_threads'] = "Normal Konular";
$l['icon_dot'] = "Sizin Yorumunuzu İçerir. ";
$l['icon_no_new'] = "Yeni Yorum Yok.";
$l['icon_new'] = "Yeni Yorum Var.";
$l['icon_hot'] = " Sıcak Konu.";
$l['icon_lock'] = " Konu Kapalı.";
$l['attachment_count'] = "Bu Konu 1 Adet Ek Dosya İçeriyor";
$l['attachment_count_multiple'] = "Bu Konu {1} Adet Ek Dosya İçeriyor";
$l['rss_discovery_forum'] = "{1} Kategorisindeki Son Konular";
$l['forum_unapproved_posts_count'] = "Şu anda Bu Forumda Onaylanmamış {1} Adet Yorum Bulunuyor.";
$l['forum_unapproved_post_count'] = "Bu Forumda Şu anda 1 Adet Onaylanmamış Yorum Bulunuyor.";
$l['forum_unapproved_threads_count'] = "Şu anda Bu Forumda Onaylanmamış {1} Adet Konu Bulunuyor.";
$l['forum_unapproved_thread_count'] = "Bu Forumda Şu anda 1 Adet Onaylanmamış Konu Bulunuyor.";
$l['thread_unapproved_posts_count'] = "Şu anda Bu Konuda Onaylanmamış {1} Adet Yorum Bulunuyor.";
$l['thread_unapproved_post_count'] = "Bu Konuda Şu anda 1 Adet Onaylanmamış Yorum Bulunuyor.";
$l['page_selected'] = "Bu Sayfada Toplam: <strong>{1}</strong> Konu Seçili.";
$l['all_selected'] = "Bu Forumdaki Toplam: <strong>{1}</strong> Konunun Tümü Seçili.";
$l['select_all'] = "Bu Forumda Toplam: <strong>{1}</strong> Konu Daha Var. [Tümünü Seç]";
$l['clear_selection'] = "[Seçimi İptal Et]";

$l['error_containsnoforums'] = "Üzgünüz: Fakat, şu anda bakmakta olduğunuz foruma bağlı hiçbir alt forum oluşturulmamış.";

$l['inline_edit_description'] = '(Tıkla ve düzenlemek için basılı tut)';
