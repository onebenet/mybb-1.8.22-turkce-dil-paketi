﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['nav_portal'] = "Portal";
$l['posted_by'] = "Yazar:";
$l['forum'] = "Forum:";
$l['replies'] = "Yorumlar";
$l['no_replies'] = "Yorum Yok";
$l['latest_threads'] = "Son Aktiviteler";
$l['latest_threads_replies'] = "Yorumlar:";
$l['latest_threads_views'] = "Okunma:";
$l['latest_threads_lastpost'] = "Son Yorum:";
$l['private_messages'] = "Özel Mesajlar";
$l['pms_received_new'] = "{1}, Sitemize son ziyaretinizden bu yana<br /> Toplam: <strong>{2}</strong> tane yeni özel mesajınız bulunuyor.";
$l['pms_unread'] = "Okunmamış Mesajlarınız";
$l['pms_total'] = "Toplam Mesajlarınız";
$l['search_forums'] = "Forumda Ara";
$l['advanced_search'] = "Gelişmiş Arama";
$l['forum_stats'] = "Forum İstatistikleri";
$l['num_members'] = "Toplam Üyeler:";
$l['latest_member'] = "Son Üye:";
$l['num_threads'] = "Toplam Konular:";
$l['num_posts'] = "Toplam Yorumlar:";
$l['full_stats'] = "Detaylı İstatistikler";
$l['welcome'] = "Hoşgeldin, {1}";
$l['guest'] = "Ziyaretçi";
$l['guest_welcome_registration'] = "Sitemizden yararlanabilmek için <a rel=\"nofollow\" href=\"{1}\" title=\"Üye Olmak İçin Tıklayın.\">Kayıt</a> olmalısınız.";
$l['username'] = "Kullanıcı Adınız:";
$l['password'] = "Şifreniz:";
$l['login'] = "Giriş Yap";
$l['member_welcome_lastvisit'] = "Son Ziyaretiniz:";
$l['since_then'] = "";
$l['new_announcements'] = "{1} Yeni Duyuru";
$l['new_announcement'] = "1 Yeni Duyuru";
$l['new_threads'] = "{1} Yeni Konu";
$l['new_thread'] = "1 Yeni Konu";
$l['new_posts'] = "{1} Yeni Yorum";
$l['new_post'] = "1 Yeni Yorum";
$l['view_new'] = "Son Aktiviteler";
$l['view_todays'] = "Bugünkü Yorumlar";
$l['online'] = "Kimler Çevrimiçi";
$l['online_user'] = "Toplam: <strong>1</strong> kullanıcı aktif";
$l['online_users'] = "Toplam: <strong>{1}</strong> kullanıcı aktif";
$l['online_counts'] = "<strong>{1}</strong> Kayıtlı<br /><strong>&raquo;</strong> <strong>{2}</strong> Ziyaretçi";
$l['no_one'] = "Hiç kimse";
$l['print_this_item'] = "Bu konuyu yazdır";
$l['send_to_friend'] = "Bu konuyu bir arkadaşına gönder";
$l['latest_announcements'] = "Son Duyurular";
$l['portal_disabled'] = "Portal işlevselliği forum yöneticisi tarafından kullanıma kapatılmıştır.";
