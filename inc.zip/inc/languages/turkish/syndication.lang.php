<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 T�rk�e Dil Paketi
 * Telif Hakk� 2020 ONEBE.NET, T�m Haklar� Sakl�d�r
 */

$l['all_forums'] = "Forumlar";
$l['forum'] = "Forum:";
$l['posted_by'] = "Yazar:";
$l['on'] = "A��k";
$l['portal'] = "Portal";