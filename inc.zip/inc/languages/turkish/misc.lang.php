<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 T�rk�e Dil Paketi
 * Telif Hakk� 2020 ONEBE.NET, T�m Haklar� Sakl�d�r
 */

$l['nav_helpdocs'] = "Yard�m Belgeleri";
$l['nav_smilies'] = "�fade Listesi";
$l['nav_syndication'] = "RSS Beslemesi";

$l['aol_im'] = "AOL IM";
$l['skype'] = "Skype";
$l['yahoo_im'] = "Yahoo IM";
$l['skype_center'] = "Skype Merkezi";
$l['chat_on_skype'] = "{1}, Skype �zerinden Sohbet Et";
$l['call_on_skype'] = "{1}, Skype �zerinden �a�r� G�nder";
$l['yahoo_center'] = "Yahoo! Merkezi";
$l['send_y_message'] = "{1}, Yahoo! �zerinden Mesaj G�nder.";
$l['view_y_profile'] = "{1}, Yahoo!'daki Profiline Bak.";
$l['aim_center'] = "AOL IM Merkezi";

$l['download_aim'] = "AIM �ndir";
$l['aim_remote'] = "Uzak AIM Eri�imi";
$l['send_me_instant'] = "Anl�k Mesaj G�nder";
$l['add_me_buddy_list'] = "Arkada� Listene Ekle";
$l['add_remote_to_page'] = "Uzaktan Eri�im Sayfas�na Ekle";
$l['download_aol_im'] = "Anl�k AOL Haberlerini �ndir";

$l['buddy_list'] = "Arkada� Listesi";
$l['online'] = "�evrimi�i Olanlar:";
$l['online_none'] = "<em>�u anda hi�bir arkada��n�z �evrimi�i de�il. :(</em>";
$l['offline'] = "�evrimd��� Olanlar:";
$l['offline_none'] = "<em>�u anda �evrimd��� hi�bir arkada��n�z yok. :)</em>";
$l['delete_buddy'] = "X";
$l['pm_buddy'] = "�zel Mesaj G�nder";
$l['last_active'] = "<strong>Son Aktiflik:</strong> {1}";
$l['close'] = "Pencereyi Kapat";
$l['no_buddies'] = "<em>Sizin arkada� listeniz �u anda bo�. Arkada� eklemek i�in tan�d���n�z kullan�c�lar�n profil sayfalar�ndan yada kullan�c� kontrol panelinizden i�lem yapabilirsiniz.</em>";

$l['help_docs'] = "Yard�m Belgeleri";

$l['search_help_documents'] = "Ara";
$l['search_by_name'] = "Belge i�i ara";
$l['search_by_document'] = "Belge ismi ara";
$l['enter_keywords'] = "Arama terimi..";
$l['search'] = "Yard�m Belgelerinde Ara";
$l['redirect_searchresults'] = "Te�ekk�rler, Arama teriminiz i�leme al�nd� ve arama sonu�lar� sayfas�na y�nlendiriliyorsunuz.";
$l['search_results'] = "Yard�m Belgesi Arama Sonu�lar�";
$l['help_doc_results'] = "Arama Sonu�lar�";
$l['document'] = "Belge";
$l['error_nosearchresults'] = "�zg�n�z fakat, arama teriminizle e�le�en hi�bir sonu� bulunumad�. L�tfen, geri d�n�p farkl� bir arama terimi deneyiniz.";
$l['no_help_results'] = "�zg�n�z fakat, arama teriminizle e�le�en hi�bir sonu� bulunumad�.";
$l['error_helpsearchdisabled'] = "Yard�m Belgelerinde arama yapma sistemi, forum y�neticisi taraf�ndan devre d��� b�rak�ld�.";

$l['smilies_listing'] = "�fade Listesi";
$l['name'] = "�sim";
$l['abbreviation'] = "K�saltma";
$l['click_to_add'] = "�fadelerden birine t�klay�p mesaj�n�za ekleyebilirsiniz";
$l['close_window'] = "Pencereyi Kapat";
$l['no_smilies'] = "�u anda hi�bir ifade mevcut de�il.";

$l['who_posted'] = "Kimler Cevaplam��?";
$l['total_posts'] = "Toplam Yorumlar:";
$l['user'] = "Kullan�c�lar";
$l['num_posts'] = "Yorumlar";

$l['forum_rules'] = "{1} - Kurallar�";

$l['error_invalid_limit'] = "Ge�ersiz RSS limiti girdiniz. L�tfen ge�erli bir limit giriniz.";

$l['syndication'] = "RSS Beslemesi";
$l['syndication_generated_url'] = "Olu�turulan Rss Besleme URL'si:";
$l['syndication_note'] = "Bu k�s�mdan, kendinize �zel RSS URL ba�lant�lar� olu�turabilirsiniz.<br />(T�m Forumlar RSS), sekmesini se�ebilir veya men�deki se�eneklerden besleme almak istedi�iniz tek bir forumu se�ebilirsiniz.";
$l['syndication_forum'] = "RSS Besleme URL'si olu�turulacak forumlar:";
$l['syndication_forum_desc'] = "L�tfen sa� taraftaki men�den beslemesini almak istedi�iniz bir forum se�iniz. �oklu veya �zel se�im i�in <b>(Ctrl)</b> tu�unu kullanabilirsiniz. t�m forumlar�n beslemesini almak i�in <b>(T�m Forumlar RSS)</b> sekmesine t�klay�n�z.";
$l['syndication_version'] = "RSS Feed Versiyon Se�imi:";
$l['syndication_version_desc'] = "L�tfen sa� taraftaki se�eneklerden, olu�turmak istedi�iniz RSS beslemesinin s�r�m�n� se�iniz.";
$l['syndication_version_atom1'] = "Atom 1.0";
$l['syndication_version_rss2'] = "RSS 2.00 (Varsay�lan S�r�m)";
$l['syndication_generate'] = "RSS Besleme URL'sini olu�tur";
$l['syndication_limit'] = "Limit Ayarlar�:";
$l['syndication_limit_desc'] = "Sa� taraftan, sayfa ba��na g�sterilecek, konu say�s�n� giriniz. Sayfa ba��na g�sterilecek maksimum konu say�s� <b>50</b>'yi ge�memesi tavsiye edilir.";
$l['syndication_threads_time'] = "Sayfa ba��na g�sterilecek, konu say�s�n� giriniz. (varsay�lan se�im 15)";
$l['syndicate_all_forums'] = "T�m Forumlar RSS";

$l['redirect_markforumread'] = "Se�ilen forumlar okundu olarak i�aretlendi.";
$l['redirect_markforumsread'] = "T�m forumlar okundu olarak i�aretlendi.";
$l['redirect_forumpasscleared'] = "Bu forum i�in kullan�lan �ifre ba�ar�l� olarak temizlendi.";
$l['redirect_cookiescleared'] = "T�m �erezler ba�ar�l� olarak silindi.";

$l['error_invalidforum'] = "Ge�ersiz forum";
$l['error_invalidhelpdoc'] = "Belirtilen Yard�m Belgesi Bulunam�yor.";
$l['error_invalidimtype'] = "Bu Kullan�c�n�n Profil Bilgilerinde, Hi�bir �leti�im Bilgisi Belirtilmemi�.";

$l['error_invalidsearch'] = "Ge�ersiz bir arama tespit edildi. L�tfen geri d�n�n ve tekrar deneyin.";
$l['error_no_search_support'] = "Veritaban� sistemi bu aramay� desteklemiyor.";
$l['error_searchflooding'] = "�zg�n�z, fakat arama sistemini sadece {1} saniyede bir kullanabilirsiniz. Tekrar arama yapabilmek i�in l�tfen, {2} saniye daha bekleyin.";
$l['error_searchflooding_1'] = "�zg�n�z, fakat arama sistemini sadece {1} saniyede bir kullanabilirsiniz. Tekrar arama yapabilmek i�in l�tfen, 1 saniye daha bekleyin.";

$l['dst_settings_updated'] = "Yaz saati zaman ayarlar� otomatik olarak ayarlanm��t�r.<br /><br />�imdi Forum Ana Sayfas�na Y�nlendiriliyorsunuz...";
