﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['nav_sendthread'] = "Bu Konuyu Arkadaşına Gönder";

$l['send_thread'] = "Konuyu Arkadaşına Gönder";
$l['recipient'] = "Alıcı Bilgileri:";
$l['recipient_note'] = "Konuyu Göndermek İstediğiniz Arkadaşınızın E-posta Adresini Yazınız.";
$l['subject'] = "Konu Başlığı:";
$l['message'] = "Mesaj İçeriği:";

$l['error_nosubject'] = "Konu Hakkında Mesajınıza Bir Başlık Eklemeniz Gerekiyor.";
$l['error_nomessage'] = "Bu Konuyu Göndermeden Önce, Konu Hakkında Kısa Bir Mesaj Yazmanız Gerekiyor.";
