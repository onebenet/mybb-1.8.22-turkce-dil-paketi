﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['boardstats'] = "Forum İstatistikleri";
$l['new_posts'] = "Yeni Yorum Var";
$l['no_new_posts'] = "Yeni Yorum Yok";
$l['forum_locked'] = "Forum Kapalı";
$l['forum_unapproved_posts_count'] = "Şu an forumda {1} adet onaylanmamış yorum bulunmaktadır.";
$l['forum_unapproved_post_count'] = "Şu an forumda 1 adet onaylanmamış yorum bulunmaktadır.";
$l['forum_unapproved_threads_count'] = "Şu an forumda {1} adet onaylanmamış konu bulunmaktadır.";
$l['forum_unapproved_thread_count'] = "Şu an forumda 1 adet onaylanmamış konu bulunmaktadır.";
$l['markread'] = "Forumları Okundu Kabul Et";
$l['forumteam'] = "Forum Yöneticileri";
$l['forumstats'] = "Forum İstatistikleri";
$l['todays_birthdays'] = "Bugün Doğum Günü Olan Arkadaşlarımız.";
$l['birthdayhidden'] = "Gizli";
$l['quick_login'] = "Hızlı Giriş Yap:";
$l['index_logout'] = "Çıkış Yap";
$l['private_messages'] = "Özel Mesajlar";
$l['pms_new'] = "Son ziyaretinizden bu yana toplam {1} adet yeni mesajınız var.";
$l['pms_unread_total'] = "(Şu an {1} okunmamış ve toplam {2} adet mesajınız bulunmaktadır.)";
$l['stats_posts_threads'] = "Toplam Konular: <strong>{2}</strong><br />Toplam Yorumlar: <strong>{1}</strong>";
$l['stats_numusers'] = "Toplam Kayıtlı Kullanıcılar: <strong>{1}</strong>";
$l['stats_newestuser'] = "Son Kayıt Olan Kullanıcı: <strong>{1}</strong>, Aramıza Hoşgeldiniz.";
$l['stats_mostonline'] = "Online Rekorumuz: <strong>{1}</strong> Kullanıcı İle {2} Tarihinde, Saat {3} Gerçekleşmiştir.";
$l['whos_online'] = "Kimler Çevrimiçi";
$l['complete_list'] = "Ayrıntılı Liste";
$l['online_online_plural'] = "Kullanıcı";
$l['online_online_singular'] = "Kullanıcı";
$l['online_member_plural'] = "Kullanıcı";
$l['online_member_singular'] = "Kullanıcı";
$l['online_anon_plural'] = "";
$l['online_anon_singular'] = "";
$l['online_guest_plural'] = "Ziyaretçi";
$l['online_guest_singular'] = "Ziyaretçi";
$l['online_note'] = "Son <strong>{3}</strong> Dakika İçinde Toplam: <strong>{1}</strong> Kullanıcı Aktif Oldu. Şu an Forumumuzda: [<a rel=\"nofollow\" href=\"./online.php\"><strong>{4} Kayıtlı, {6} Gizli ve {8} Ziyaretçi</strong></a>] Bulunmaktadır.";
$l['subforums'] = "Alt Forumlar:";
