﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['nav_showteam'] = "Forum Yöneticileri";
$l['forum_team'] = "Forum Yöneticileri";
$l['moderators'] = "Yöneticiler";
$l['username'] = "Kullanıcı Adı";
$l['lastvisit'] = "Son Ziyareti";
$l['email'] = "E-Posta";
$l['pm'] = "ÖM";
$l['mod_forums'] = "Sorumlu Olduğu Forum ve Bölümler";
$l['online'] = "Çevrimiçi";
$l['offline'] = "Çevrimdışı";
$l['away'] = "İzinde";

$l['group_leaders'] = "Grup Liderleri";
$l['group_members'] = "Üyeler";

$l['no_members'] = "Bu grubta henüz hiç üye yok.";

$l['error_noteamstoshow'] = "Şu anda gösterilecek herhangi bir yönetici mevcut değil.";
