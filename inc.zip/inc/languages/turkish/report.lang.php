﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['report_reason'] = "Rapor Sebebi:";
$l['report_to_mod'] = "Bu İçeriği Yöneticilere Rapor Et";
$l['close_window'] = "Pencereyi Kapat";

// Content types
$l['report_content'] = "Rapor İçeriği";
$l['report_reason_post'] = "Raporu Gönder";
$l['report_reason_profile'] = "Profili Rapor Et";
$l['report_reason_reputation'] = "Rep Puanını Rapor Et";

// Content reasons
$l['report_reason_rules'] = "Forum Kurallarına Aykırı";
$l['report_reason_bad'] = "Sakıncalı İçerik";
$l['report_reason_spam'] = "Spam İçerik";
$l['report_reason_wrong'] = "Yanlış Giden Bir Şeyler Var";
$l['report_reason_other'] = "Diğer Belirtiniz";

$l['success_report_voted'] = "Rapor ettiğiniz için teşekkürler.<br />Forum ekibinin bir üyesi en kısa zamanda bu raporu kontrol edecektir.";

$l['error_report_length'] = "Lütfen, Raporunuz için ayrıltılı bir sebep giriniz.";
$l['error_invalid_report'] = "Bu içerik ya mevcut değil ya da rapor edilmesi mümkün değil.";
$l['error_invalid_report_reason'] = "Seçilen rapor sebebi geçersiz.";
$l['error_comment_required'] = "Seçilen sebep için ek bir açıklama yazmanız gerekli.";
$l['error_report_duplicate'] = "Bu içerik zaten başka bir kullanıcı tarafından daha önce rapor edilmiş.<br />Yinede aşağıdaki butona tıklayıp içeriği rapor edebilirsiniz.";
$l['report_reason_other_description'] = "Lütfen, aşağıdaki metin kutusuna rapor etme sebebiniz için kısa bir açıklama yazınız.";
