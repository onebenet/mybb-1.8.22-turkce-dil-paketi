﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['nav_announcements'] = "Forum Duyurusu";
$l['announcements'] = "Duyuru";
$l['forum_announcement'] = "Forum Duyurusu: {1}";
$l['error_invalidannouncement'] = "Geçersiz Duyuru";

$l['announcement_edit'] = "Bu Duyuruyu Düzenle";
$l['announcement_qdelete'] = "Bu Duyuruyu Sil";
$l['announcement_quickdelete_confirm'] = "Bu duyuruyu silmek istediğinizden emin misiniz?";

