<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['redirect_width'] = "50%";
$l['lastvisit_never'] = "Hiçbir Zaman";
$l['lastvisit_hidden'] = "(Gizli)";

$l['search_button'] = 'Ara';
$l['toplinks_memberlist'] = "Üye Listesi";
$l['toplinks_search'] = "Arama";
$l['toplinks_calendar'] = "Takvim";
$l['toplinks_help'] = "Yardım";
$l['toplinks_portal'] = "Portal";
$l['bottomlinks_forumteam'] = "Forum Takımı";
$l['bottomlinks_contactus'] = "İletişim";
$l['bottomlinks_returntop'] = "Yukarı Git";
$l['bottomlinks_syndication'] = "RSS Beslemesi";
$l['bottomlinks_litemode'] = "Arşiv";
$l['bottomlinks_markread'] = "Tüm forumları okundu olarak işaretle";

$l['welcome_usercp'] = "Kullanıcı Paneli";
$l['welcome_modcp'] = "Moderatör Paneli";
$l['welcome_admin'] = "Admin Paneli";
$l['welcome_logout'] = "Çıkış yap";
$l['welcome_login'] = "Giriş yap";
$l['welcome_register'] = "Üye ol";
$l['welcome_open_buddy_list'] = "Arkadaşlarım";
$l['welcome_newposts'] = "Son Aktiviteler";
$l['welcome_todaysposts'] = "Bugünkü Yorumlar";
$l['welcome_pms'] = "Özel Mesajlarınız:";
$l['welcome_pms_usage'] = "Toplam {2}, Okunmamış {1}";
$l['welcome_back'] = "<strong>Hoşgeldin, {1}</strong>. Son Ziyaretiniz: {2}";
$l['welcome_guest'] = "Hoşgeldin, Ziyaretçi:";
$l['welcome_current_time'] = "<strong>Tarih:</strong> {1}";

$l['moved_prefix'] = "Taşındı:";
$l['poll_prefix'] = "Anket:";

$l['forumbit_announcements'] = "Duyurular";
$l['forumbit_stickies'] = "Sabit Konular";
$l['forumbit_forum'] = "Forumlar";
$l['forumbit_threads'] = "Konular";
$l['forumbit_posts'] = "Yorumlar";
$l['forumbit_lastpost'] = "Son Yorumlar";
$l['forumbit_moderated_by'] = "Yönetici:";
$l['new_posts'] = "Forum'da Yeni Yorum Var";
$l['no_new_posts'] = "Forum'da Yeni Yorum Yok";
$l['click_mark_read'] = "Forumları Okundu Kabul Et";
$l['forum_locked'] = "Forum Kilitli";
$l['forum_redirect'] = "Forum Yönlendirme";
$l['lastpost_never'] = "Henüz Yok";
$l['viewing_one'] = " (1 Kullanıcı İçerde)";
$l['viewing_multiple'] = " ({1} Kullanıcı İçerde)";
$l['by'] = "Yazar:";
$l['more_subforums'] = "{1}, Alt forum daha Var.";

$l['password_required'] = "Giriş yapabilmeniz için şifre gerekiyor.";
$l['forum_password_note'] = "Site Yönetimi Tarafından Şifrelenmiş Bir Foruma Girmeye Çalışıyorsunuz.</p> Bu foruma erişebilmek ve işlem yapabilmeniz için site yöneticisinden şifre almanız gerekiyor..Eğer bir Şifreniz varsa, Lütfen aşağıdaki kutucuğa yazarak giriş yapınız.";
$l['enter_password_below'] = "<center>(Lütfen şifrenizi aşağıdaki kutucuğa yazınız)</center>";
$l['verify_forum_password'] = "Giriş Yap";
$l['wrong_forum_password'] = "Girmiş olduğunuz şifre yanlış. Lütfen şifrenizin doğruluğunu kontrol ederek tekrar deneyiniz.";

$l['reset_button'] = "Sıfırla";
$l['username'] = "Kullanıcı:";
$l['username1'] = "E-mail:";
$l['username2'] = "Kullanıcı Adı/E-posta:";
$l['password'] = "Şifre:";
$l['login_username'] = "Kullanıcı:";
$l['login_username1'] = "E-mail:";
$l['login_username2'] = "Kullanıcı Adı/E-posta:";
$l['login_password'] = "Şifre:";
$l['lost_password'] = "Şifremi Unuttum?";
$l['remember_me'] = "Beni Hatırla";
$l['remember_me_desc'] = "Bu seçenek, forumdan çıkış yapmadığınız sürece, her ziyaretinizde giriş bilgilerinizin otomatik olarak hatırlanmasını sağlar.";

$l['month_1'] = "Ocak";
$l['month_2'] = "Şubat";
$l['month_3'] = "Mart";
$l['month_4'] = "Nisan";
$l['month_5'] = "Mayıs";
$l['month_6'] = "Haziran";
$l['month_7'] = "Temmuz";
$l['month_8'] = "Ağustos";
$l['month_9'] = "Eylül";
$l['month_10'] = "Ekim";
$l['month_11'] = "Kasım";
$l['month_12'] = "Aralık";

$l['sunday'] = "Pazar";
$l['monday'] = "Pazartesi";
$l['tuesday'] = "Salı";
$l['wednesday'] = "Çarşamba";
$l['thursday'] = "Perşembe";
$l['friday'] = "Cuma";
$l['saturday'] = "Cumartesi";
$l['short_monday'] = "Pt";
$l['short_tuesday'] = "Sa";
$l['short_wednesday'] = "Ça";
$l['short_thursday'] = "Pe";
$l['short_friday'] = "Cu";
$l['short_saturday'] = "Ct";
$l['short_sunday'] = "Pz";

$l['yes'] = "Evet";
$l['no'] = "Hayır";

$l['and'] = "ve";
$l['date'] = "Tarih";

$l['nobody'] = "Nobody";

$l['attachments'] = "Ek Dosya Yönetimi:";
$l['attachments_desc'] = "Dilerseniz bu konuya bir veya daha fazla ek dosya ekleyebilirsiniz. Lütfen <b>Gözat</b> butonuna tıklayıp bilgisayarınızdan yüklemek istediğiniz dosyayı seçiniz ve (Dosyayı Yükle) butonuna tıklayınız.";
$l['remove_attachment'] = "Sil";
$l['approve_attachment'] = "Onayla";
$l['unapprove_attachment'] = "Onaylama";
$l['insert_attachment_post'] = "Konuya Ekle";
$l['new_attachment'] = "Ek Dosya Ekle:";
$l['add_attachment'] = "Dosyayı Yükle";
$l['update_attachment'] = "Dosyayı Güncelle";
$l['attachment_too_many_files'] = "Bir seferde en fazla {1} dosya yükleyebilirsiniz.";
$l['attachment_too_big_upload'] = "Bir seferde en fazla {1} dosya yükleyebilirsiniz..";
$l['post_preview'] = "Önizleme Yap";
$l['change_user'] = "Kullanıcı Değiştir";
$l['post_icon'] = "Başlık Sembolleri:";
$l['no_post_icon'] = "Sembol eklemek istemiyorum?";
$l['thread_subscription_method'] = "<strong>Konu Takip Yönetimi:</strong><br /><span class=\"smalltext\">Dilerseniz bu konuyu takip ederek, yazılan her yorumdan haberdar olabilir yada devre dışı bırakabilirsiniz.</span>";
$l['thread_subscription_method_desc'] = "bu ileti dizisine sahip olmak istediğiniz bildirim türünü ve ileti dizisi aboneliğini belirtin. (Sadece kayıtlı kullanıcılar)";
$l['no_subscribe'] = "Bu konuyu takip etmek istemiyorum?";
$l['no_subscribe_notification'] = "Yeni yanıt bildirimi almadan abone olun";
$l['instant_email_subscribe'] = "Bu konuya yorum yazılınca anında E-posta bildirimi gönderilsin?";
$l['instant_pm_subscribe'] = "Abone olun ve yeni yanıtlar için PM bildirimi alın";

$l['today_rel'] = "<span title=\"{1}\">Bugün</span>";
$l['yesterday_rel'] = "<span title=\"{1}\">Dün</span>";
$l['today'] = "Bugün";
$l['yesterday'] = "Dün";
$l['error'] = "Yönetim Kurulu Mesajı";

$l['multipage_pages'] = "Toplam ({1}) Sayfa:";
$l['multipage_last'] = "Son";
$l['multipage_first'] = "İlk";
$l['multipage_next'] = "Sonraki";
$l['multipage_previous'] = "Önceki";
$l['multipage_link_start'] = " ..";
$l['multipage_link_end'] = ".. ";
$l['multipage_jump'] = "Sayfaya Git";

$l['editor_bold'] = "Kalın";
$l['editor_italic'] = "Eğik";
$l['editor_underline'] = "Altı çizili";
$l['editor_strikethrough'] = "Üstü çizili";
$l['editor_subscript'] = "alt simge";
$l['editor_superscript'] = "Üst simge";
$l['editor_alignleft'] = "Sola hizalamak";
$l['editor_center'] = "orta hizalama";
$l['editor_alignright'] = "sağa hizala";
$l['editor_justify'] = "doğrulamak";
$l['editor_fontname'] = "yazı tipi adı";
$l['editor_fontsize'] = "yazı boyutu";
$l['editor_fontcolor'] = "yazı rengi";
$l['editor_removeformatting'] = "Biçimlendirmeyi Kaldır";
$l['editor_cut'] = "kes";
$l['editor_copy'] = "kopyala";
$l['editor_paste'] = "yapıştır";
$l['editor_cutnosupport'] = "Tarayıcınız kesme komutuna izin vermiyor. Lütfen Ctrl / Cmd-X klavye kısayolunu kullanın";
$l['editor_copynosupport'] = "Tarayıcınız kopyalama komutuna izin vermiyor. Lütfen Ctrl / Cmd-C klavye kısayolunu kullanın ";
$l['editor_pastenosupport'] = "Tarayıcınız yapıştır komutuna izin vermiyor. Lütfen Ctrl / Cmd-V klavye kısayolunu kullanın";
$l['editor_pasteentertext'] = "Metninizi aşağıdaki kutunun içine yapıştırın:";
$l['editor_pastetext'] = "Metin Yapıştır";
$l['editor_numlist'] = "Numaralı liste ekle";
$l['editor_bullist'] = "Noktalı liste ekle";
$l['editor_undo'] = "Geri alma";
$l['editor_redo'] = "Tekrar";
$l['editor_rows'] = "Satır:";
$l['editor_cols'] = "cols:";
$l['editor_inserttable'] = "Tablo ekle";
$l['editor_inserthr'] = "Yatay bir kural ekle";
$l['editor_code'] = "Biçimlendirilmiş kod ekle (Code)";
$l['editor_php'] = "Biçimlendirilmiş PHP kod ekle (PHP Code)";
$l['editor_width'] = "Genişlik (isteğe bağlı):";
$l['editor_height'] = "Yükseklik (isteğe bağlı):";
$l['editor_insertimg'] = "Resim ekle";
$l['editor_email'] = "E-mail:";
$l['editor_insertemail'] = "E-posta ekle";
$l['editor_url'] = "URL:";
$l['editor_insertlink'] = "Bağlantı ekle";
$l['editor_unlink'] = "Bağlantıyı kaldır";
$l['editor_more'] = "Daha";
$l['editor_insertemoticon'] = "İfade ekleyin";
$l['editor_videourl'] = "Video Link:";
$l['editor_videotype'] = "Video Türü:";
$l['editor_insert'] = "Ekle";
$l['editor_insertyoutubevideo'] = "Bir YouTube videosu ekleyin";
$l['editor_currentdate'] = "Geçerli tarihi ekle";
$l['editor_currenttime'] = "Geçerli saati ekle";
$l['editor_print'] = "Yazdır";
$l['editor_viewsource'] = "Kaynağı görüntüle";
$l['editor_description'] = "Açıklama (isteğe bağlı):";
$l['editor_enterimgurl'] = "Resim URL'sini girin:";
$l['editor_enteremail'] = "E-posta adresini girin:";
$l['editor_enterdisplayedtext'] = "Görüntülenen metni girin:";
$l['editor_enterurl'] = "URL girin:";
$l['editor_enteryoutubeurl'] = "YouTube video URL'sini veya kimliğini girin:";
$l['editor_insertquote'] = "Bir Teklif Ekle";
$l['editor_invalidyoutube'] = "Geçersiz YouTube videosu";
$l['editor_dailymotion'] = "Dailymotion";
$l['editor_metacafe'] = "MetaCafe";
$l['editor_mixer'] = "Mixer";
$l['editor_vimeo'] = "Vimeo";
$l['editor_youtube'] = "Youtube";
$l['editor_twitch'] = "Twitch";
$l['editor_facebook'] = "Facebook";
$l['editor_liveleak'] = "LiveLeak";
$l['editor_insertvideo'] = "Video ekle";
$l['editor_maximize'] = "Üst Düzey";

$l['quote'] = "Alıntı:";
$l['wrote'] = " Nickli Kullanıcıdan Alıntı:";
$l['code'] = "Kod:";
$l['php_code'] = "PHP Kod:";
$l['posted_image'] = "[Resim: {1}]";
$l['posted_video'] = "[Video: {1}]";
$l['linkback'] = "Orjinal Konu";

$l['at'] = "";
$l['na'] = "N/A";
$l['guest'] = "Ziyaretçi";
$l['unknown'] = "Bilinmeyen";
$l['never'] = "Hiçbir Zaman";
$l['postbit_posts'] = "Yorum Sayısı:";
$l['postbit_threads'] = "konu:";
$l['postbit_group'] = "Grup:";
$l['postbit_joined'] = "Üyelik Tarihi:";
$l['postbit_status'] = "Şu anki Konumu:";
$l['postbit_attachments'] = "Ek Dosya-(lar)";
$l['postbit_attachment_filename'] = "Dosya Adı:";
$l['postbit_attachment_size'] = "Dosya Boyutu:";
$l['postbit_attachment_downloads'] = "İndirme Sayısı:";
$l['postbit_attachments_images'] = "Resim-(ler)";
$l['postbit_attachments_thumbnails'] = "Ekran Görüntüleri";
$l['postbit_unapproved_attachments'] = "{1} Onaylanmamış Eklenti-(ler).";
$l['postbit_unapproved_attachment'] = "1 Onaylanmamış Eklenti.";
$l['postbit_status_online'] = "Çevrimiçi";
$l['postbit_status_offline'] = "Çevrimdışı";
$l['postbit_status_away'] = "İzinli";
$l['postbit_edited'] = "Bu konu en son: {1} Tarihinde, Saat: {2} düzenlenmiştir. Düzenleyen: ";
$l['postbit_editreason'] = "Nedeni Düzenle";
$l['postbit_ipaddress'] = "IP No:";
$l['postbit_ipaddress_logged'] = "Göster";
$l['postbit_post'] = "Yorum:";
$l['postbit_reputation'] = "Rep Puanı:";
$l['postbit_reputation_add'] = "Bu Mesaj için Rep Ver";
$l['postbit_website'] = "Web Sitesini Ziyaret Et";
$l['postbit_email'] = "E-posta Gönder";
$l['postbit_find'] = "Tüm Mesajlarına Bak";
$l['postbit_report'] = "Bu Mesajı Rapor Et";
$l['postbit_quote'] = "Alıntı ile Cevapla";
$l['postbit_qdelete_post'] = "Bu gönderiyi sil";
$l['postbit_qdelete_thread'] = "Bu konuyu sil";
$l['postbit_qrestore_post'] = "Bu yayını geri yükle";
$l['postbit_qrestore_thread'] = "Bu konuyu geri yükle";
$l['postbit_profile'] = "Profil Bilgilerine Bak";
$l['postbit_pm'] = "Özel Mesaj Gönder";
$l['postbit_edit'] = "Bu Mesajı Düzenle/Sil";
$l['postbit_multiquote'] = "Çoklu Alıntı olarak Seç";
$l['postbit_quick_edit'] = "Hızlı Düzenle";
$l['postbit_full_edit'] = "Gelişmiş Düzenle";
$l['postbit_show_ignored_post'] = "Gizli İçeriği Göster";
$l['postbit_currently_ignoring_user'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> Bu Konu veya Yorumun içeriği gizlidir. Çünkü <strong> {1} </strong>nickli kullanıcı sizin tarafınızdan, engelli listenizde kayıtlıdır.<br /> Bu engeli kaldırmak istiyorsanız eğer <a rel=\"nofollow\" href=\"usercp.php?action=editlists\"><strong>Buradan</strong></a> engelliler Listesi ne Giderek, <strong> {1} </strong>nickli kullanıcıya ait engeli kaldırabilirsiniz.<br /> Veya engeli kaldırmadan, sağ taraftaki <strong>(Gizli içeriği Göster)</strong>, butonuna tıklayıp konuyu görebilirsiniz.";
$l['postbit_post_under_moderation'] = "Yaptığınız yayın denetleniyor ve şu anda herkese açık değil. Bir moderatör onayladığında gönderi herkes tarafından görülebilir.";
$l['postbit_warning_level'] = "Uyarı Puanı:";
$l['postbit_warn'] = "Bu Mesaj için Uyarı Ver";
$l['postbit_purgespammer'] = "Purge Spammer";
$l['postbit_post_deleted'] = "Bu yayın silindi.";
$l['postbit_post_unapproved'] = "Bu yayın onay bekliyor.";
$l['postbit_thread_deleted'] = "This thread has been deleted.";
$l['postbit_thread_unapproved'] = "Bu konu onay bekliyor.";
$l['postbit_deleted_post_user'] = "{1} tarafından gönderilen bu yayın silindi.";

$l['postbit_button_reputation_add'] = 'Bu Mesaj için Rep Ver';
$l['postbit_button_website'] = 'Web Sitesini Ziyaret Et';
$l['postbit_button_email'] = 'E-posta Gönder';
$l['postbit_button_find'] = 'Tüm Mesajlarına Bak';
$l['postbit_button_report'] = 'Bu Mesajı Rapor Et';
$l['postbit_button_quote'] = 'Alıntı ile Cevapla';
$l['postbit_button_qdelete'] = 'Bu Mesajı Sil';
$l['postbit_button_qrestore'] = 'Düzelt';
$l['postbit_button_profile'] = 'Profil Bilgilerine Bak';
$l['postbit_button_pm'] = 'Özel Mesaj Gönder';
$l['postbit_button_warn'] = 'Bu Mesaj için Uyarı Ver"';
$l['postbit_button_edit'] = 'Düzenle';
$l['postbit_button_multiquote'] = 'Alıntı';
$l['postbit_button_reply_pm'] = 'Yanıtla';
$l['postbit_button_reply_all'] = 'Hepsini Yanıtla';
$l['postbit_button_forward'] = 'ileri';
$l['postbit_button_delete_pm'] = 'Sil';
$l['postbit_button_purgespammer'] = "Spam Göndericiyi Temizle";

$l['forumjump'] = "Hızlı Menü:";
$l['forumjump_pms'] = "Özel Mesajlarınız";
$l['forumjump_usercp'] = "Kullanıcı Kontrol Paneli";
$l['forumjump_wol'] = "Kimler Çevrimiçi";
$l['forumjump_search'] = "Gelişmiş Arama";
$l['forumjump_home'] = "Forum Ana Sayfası";

$l['redirect'] = "Yönlendiriliyorsunuz, Lütfen bekleyin...";
$l['unknown_error'] = "Sebebi bilinmeyen bir hata oluştu.";
$l['post_fetch_error'] = 'Yayınlar getirilirken bir hata oluştu.';

$l['smilieinsert'] = "İfadeler";
$l['smilieinsert_getmore'] = "Daha fazla göster";
$l['on'] = "Açık";
$l['off'] = "Kapalı";
$l['remote_avatar_disabled_default_avatar'] = "Şu anda devre dışı bırakılmış bir uzak avatar kullanıyorsunuz. Bunun yerine varsayılan avatar kullanılacak.";
$l['mod_notice'] = "Denetleme Bekliyor: {1}.";
$l['unapproved_thread'] = "1 onaylanmamış konu";
$l['unapproved_threads'] = "{1} onaylanmamış konular";
$l['unapproved_post'] = "1 onaylanmamış yazı";
$l['unapproved_posts'] = "{1} onaylanmamış yazılar";
$l['unapproved_attachment'] = "1 onaylanmamış ek dosya";
$l['unapproved_attachments'] = "{1} onaylanmamış ek dosyalar";
$l['unread_report'] = "1 Tane Rapor Edilen Konu Bildirimi Var.</strong>";
$l['unread_reports'] = "{1} Tane Rapor Edilen Konu Bildirimi Var.</strong>";
$l['pending_joinrequest'] = "Grup Lideri Notu: Bekleyen 1 Grup üyeliği isteğiniz var.";
$l['pending_joinrequests'] = "Grup Lideri Notu: Toplam {1} tane bekleyen grup üyeliği istekleri var.";

$l['search_user'] = "Bir kullanıcı arayın";

$l['year'] = "Yıl";
$l['year_short'] = "y";
$l['years'] = "Yıl";
$l['years_short'] = "y";
$l['month'] = "Ay";
$l['month_short'] = "a";
$l['months'] = "Ay";
$l['months_short'] = "a";
$l['week'] = "Hafta";
$l['week_short'] = "h";
$l['weeks'] = "Hafta";
$l['weeks_short'] = "h";
$l['day'] = "Gün";
$l['day_short'] = "g";
$l['days'] = "Gün";
$l['days_short'] = "g";
$l['hour'] = "Saat";
$l['hour_short'] = "s";
$l['hours'] = "Saat";
$l['hours_short'] = "s";
$l['minute'] = "Dakika";
$l['minute_short'] = "dk";
$l['minutes'] = "Dakika";
$l['minutes_short'] = "dk";
$l['second'] = "Saniye";
$l['second_short'] = "sn";
$l['seconds'] = "Saniye";
$l['seconds_short'] = "sn";

$l['rel_in'] = "İçinde ";
$l['rel_ago'] = "önce";
$l['rel_less_than'] = "Daha az ";
$l['rel_time'] = "<span title=\"{5}{6}\">{1}{2} {3} {4}</span>";
$l['rel_minutes_single'] = "dakika";
$l['rel_minutes_plural'] = "dakikalar";
$l['rel_hours_single'] = "saat";
$l['rel_hours_plural'] = "saatler";

$l['permanent'] = "kalıcı";
$l['save_draft'] = "Taslak olarak kaydet";
$l['go'] = "Git";
$l['bbclosed_warning'] = "Yönetim kurulu durumunuz şu anda kapalı.";
$l['banned_warning'] = "<div class=\"float_left\"><img src=\"images/icons/yasak.png\" style=\"vertical-align: middle;\" alt=\"\" height=\"32\" width=\"32\" /></div>Forumumuzdaki üyelik hesabınız yönetim kararı ile yasaklanmıştır.<div class=\"float_right\"><img src=\"images/icons/yasak.png\" style=\"vertical-align: middle;\" alt=\"\" height=\"32\" width=\"32\" /></div>";
$l['banned_warning2'] = "<br /><strong>Forumdan yasaklanma sebebiniz</strong>";
$l['banned_warning3'] = "<strong>Hesabınızın tekrar aktif olma süresi</strong>";
$l['banned_lifted_never'] = "Süresiz yasaklandı.";
$l['banned_email_warning'] = "E-posta adresinizin yasaklı listesinde olduğu tespit edildi. Lütfen devam etmeden önce e-porta adresinizi yenileyin.";
$l['powered_by'] = "Türkçe Çeviri: <a href=\"http://www.onebe.net\" target=\"_blank\" title=\"Türkiye'nin Yeni Bilgi Platformu\">ONEBE</a>.NET<br />Forum Yazılımı:";
$l['copyright'] = "Copyright";
$l['attach_quota'] = "Tahsis edilen ek kullanım kotanız: {1}.";
$l['attach_usage'] = "Şu anda kullanıyorsunuz <strong>{1}</strong>.";
$l['view_attachments'] = "[Eklerimi Görüntüle]";
$l['unlimited'] = "Sınırsız";

$l['click_hold_edit'] = "(Düzenlemek için tıklayın ve basılı tutun)";

$l['guest_count'] = "1 Ziyaretçi";
$l['guest_count_multiple'] = "{1} Ziyaretçi";

$l['size_yb'] = "YB";
$l['size_zb'] = "ZB";
$l['size_eb'] = "EB";
$l['size_pb'] = "PB";
$l['size_tb'] = "TB";
$l['size_gb'] = "GB";
$l['size_mb'] = "MB";
$l['size_kb'] = "KB";
$l['size_bytes'] = "bytes";

$l['slaps'] = "ifade";
$l['with_trout'] = "sunucu zaman aşımı.";

$l['mybb_engine'] = "MyBB Posta Göndericisi";
$l['quickdelete_confirm'] = "Bu yorumu silmek istediğinizden emin misiniz?";
$l['quickrestore_confirm'] = "Bu yayını geri yüklemek istediğinizden emin misiniz??";
$l['newpm_notice_one'] = "<div class=\"float_left\"><a rel=\"nofollow\" href=\"private.php?action=read&amp;pmid={2}\"><img src=\"images/icons/pm-bildirimi.gif\" style=\"vertical-align: middle;\" alt=\"\" height=\"32\" width=\"32\" /></a></div> <strong>{1} nickli kullanıcıdan yeni bir özel mesaj aldınız.<br />Mesaj Başlığı:</strong> <a rel=\"nofollow\" href=\"private.php?action=read&amp;pmid={2}\" style=\"font-weight: bold;\">{3}</a>";
$l['newpm_notice_multiple'] = "Okunmamış Toplam: <strong>[{1}]</strong> tane mesajınız var. <strong>Son Mesaj Gönderen:</strong> {2} <strong>Mesaj başlığı:</strong> <a rel=\"nofollow\" href=\"private.php?action=read&amp;pmid={3}\" style=\"font-weight: bold;\">{4}</a>";
$l['deleteevent_confirm'] = "Bu etkinliği silmek istediğinizden emin misiniz?";
$l['removeattach_confirm'] = "Bu ek dosyayı konudan tamamen silmek istediğinize emin misiniz?";

$l['latest_threads'] = "Son Aktiviteler";

$l['folder_inbox'] = "Gelen Kutusu";
$l['folder_unread'] = "Okunmamış";
$l['folder_sent_items'] = "Gönderilen Mesajlar";
$l['folder_drafts'] = "Taslaklar";
$l['folder_trash'] = "Çöp Kutusu";
$l['folder_untitled'] = "İsimsiz Klasör";

$l['standard_mod_tools'] = "Standart Araçlar";
$l['custom_mod_tools'] = "Özel Araçlar";

$l['error_loadlimit'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> Sunucu yüklenirken zaman aşımına uğradı. Lütfen daha sonra tekrar deneyiniz.";
$l['error_boardclosed'] = "<center>(<span style=\"color: maroon; font-weight: bold;\"> Forumumuz şu anda kapalıdır.</span> )<br />Kapalı olma nedenimiz aşağıda yazmaktadır.</center>";
$l['error_banned'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> <strong>Üzgünüz:</strong> Forum hesabınız yasaklanmıştır. yasaklı olduğunuz gibi forumdaki tüm erişim izinlerinizde engellenmiştir. Her hangi bir sorunuz veya yasaklı olmanız ile ilgili görüşmek istedikleriniz varsa, Lütfen forum yöneticisi ile iletişime geçiniz.";
$l['error_cannot_upload_php_post'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> Dosya boyutu büyük olduğundan işleminiz gerçekleşmedi. - Lütfen geriye dönüp yükleme işlemini tekrar deneyiniz..";
$l['error_empty_post_input'] = "Kayıt verilerinizin boş olması nedeniyle bir hata oluştu. Bunun nedeni tarayıcı sayfasının yenilenmesi veya bu sayfaya doğrudan erişim olabilir. Tarayıcı geri düğmesine basmanızı ve tekrar başlamanızı öneririz.";
$l['error_database_repair'] = "MyBB otomatik olarak sorunlu tabloların onarım ve bakımını gerçekleştiriyor.";

$l['unknown_user_trigger'] = "Bilinmeyen bir hata oluştu.";
$l['warnings'] = "Aşağıdaki hatalar oluştu:";

$l['ajax_loading'] = "Lütfen Bekleyiniz.<br />Sayfa Yükleniyor...";
$l['saving_changes'] = "Değişiklikler Kayıtlanıyor...";
$l['refresh'] = "Yenile";
$l['select_language'] = "Dil Seçenekleri";
$l['select_theme'] = "Hızlı Tema Seçimi";

$l['invalid_post_code'] = "Uygun olmayan kod hatası. Bu işlemi doğru bir şekilde yaptığınızdan eminmisiniz? Lütfen geri dönüp tekrar deneyiniz.";
$l['invalid_captcha'] = "Devam edebilmek için lütfen resim doğrulama kodunu giriniz.";
$l['invalid_captcha_verify'] = "Girdiğiniz resim doğrulama kodu yanlıştır. Lütfen resimde göründüğü şekilde giriniz.";
$l['image_verification'] = "Görüntü Doğrulama";
$l['human_verification'] = "İnsan Doğrulama";
$l['verification_note'] = "Lütfen resimde bulunan metni altındaki metin kutusuna girin. Bu işlem, otomatik spam botlarını önlemek için kullanılır.";
$l['verification_note_nocaptcha'] = "Lütfen aşağıda gördüğünüz onay kutusunu işaretleyin. Bu işlem, otomatik spam botlarını önlemek için kullanılır.";
$l['verification_subnote'] = "(büyük / küçük harfe duyarlı değil)";
$l['invalid_nocaptcha_transmit'] = "İnsan doğrulamasında bir hata oluştu. Lütfen tekrar deneyi.";
$l['captcha_fetch_failure'] = 'Yeni captcha getirilirken bir hata oluştu.';
$l['question_fetch_failure'] = 'Yeni soru getirilirken bir hata oluştu.';

$l['timezone_gmt_minus_1200'] = "(GMT -12:00) Howland and Baker Islands";
$l['timezone_gmt_minus_1100'] = "(GMT -11:00) Nome, Midway Island";
$l['timezone_gmt_minus_1000'] = "(GMT -10:00) Hawaii, Papeete";
$l['timezone_gmt_minus_950'] = "(GMT -9:30) Marquesas Islands";
$l['timezone_gmt_minus_900'] = "(GMT -9:00) Alaska";
$l['timezone_gmt_minus_800'] = "(GMT -8:00) Pacific Time";
$l['timezone_gmt_minus_700'] = "(GMT -7:00) Mountain Time";
$l['timezone_gmt_minus_600'] = "(GMT -6:00) Central Time, Mexico City";
$l['timezone_gmt_minus_500'] = "(GMT -5:00) Eastern Time, Bogota, Lima, Quito";
$l['timezone_gmt_minus_450'] = "(GMT -4:30) Caracas";
$l['timezone_gmt_minus_400'] = "(GMT -4:00) Atlantic Time, La Paz, Halifax";
$l['timezone_gmt_minus_350'] = "(GMT -3:30) Newfoundland";
$l['timezone_gmt_minus_300'] = "(GMT -3:00) Brazil, Buenos Aires, Georgetown, Falkland Is.";
$l['timezone_gmt_minus_200'] = "(GMT -2:00) Mid-Atlantic, South Georgia and the South Sandwich Islands";
$l['timezone_gmt_minus_100'] = "(GMT -1:00) Azores, Cape Verde Islands";
$l['timezone_gmt'] = "(GMT) Casablanca, Dublin, Edinburgh, London, Lisbon, Monrovia";
$l['timezone_gmt_100'] = "(GMT +1:00) Berlin, Bratislava, Brussels, Copenhagen, Madrid, Paris, Prague, Rome, Warsaw";
$l['timezone_gmt_200'] = "(GMT +2:00) İstanbul, Atina, Bükreş, Türkiye :)";
$l['timezone_gmt_300'] = "(GMT +3:00) Kaliningrad, Minsk, Baghdad, Riyadh, Nairobi";
$l['timezone_gmt_350'] = "(GMT +3:30) Tehran";
$l['timezone_gmt_400'] = "(GMT +4:00) Moscow, Abu Dhabi, Baku, Muscat, Tbilisi";
$l['timezone_gmt_450'] = "(GMT +4:30) Kabul";
$l['timezone_gmt_500'] = "(GMT +5:00) Islamabad, Karachi, Tashkent";
$l['timezone_gmt_550'] = "(GMT +5:30) Mumbai, Kolkata, Chennai, New Delhi";
$l['timezone_gmt_575'] = "(GMT +5:45) Kathmandu";
$l['timezone_gmt_600'] = "(GMT +6:00) Almaty, Dhaka, Yekaterinburg";
$l['timezone_gmt_650'] = "(GMT +6:30) Yangon";
$l['timezone_gmt_700'] = "(GMT +7:00) Bangkok, Hanoi, Jakarta";
$l['timezone_gmt_800'] = "(GMT +8:00) Beijing, Hong Kong, Perth, Singapore, Taipei, Manila";
$l['timezone_gmt_850'] = "(GMT +8:30) Pyongyang";
$l['timezone_gmt_875'] = "(GMT +8:45) Eucla";
$l['timezone_gmt_900'] = "(GMT +9:00) Osaka, Sapporo, Seoul, Tokyo, Irkutsk";
$l['timezone_gmt_950'] = "(GMT +9:30) Adelaide, Darwin";
$l['timezone_gmt_1000'] = "(GMT +10:00) Melbourne, Papua New Guinea, Sydney, Yakutsk";
$l['timezone_gmt_1050'] = "(GMT +10:30) Lord Howe Island";
$l['timezone_gmt_1100'] = "(GMT +11:00) Magadan, New Caledonia, Solomon Islands, Vladivostok";
$l['timezone_gmt_1150'] = "(GMT +11:30) Norfolk Island";
$l['timezone_gmt_1200'] = "(GMT +12:00) Auckland, Wellington, Fiji, Marshall Islands";
$l['timezone_gmt_1275'] = "(GMT +12:45) Chatham Islands";
$l['timezone_gmt_1300'] = "(GMT +13:00) Samoa, Tonga, Tokelau";
$l['timezone_gmt_1400'] = "(GMT +14:00) Line Islands";
$l['timezone_gmt_short'] = "GMT {1}({2})";

$l['missing_task'] = "<strong>Hata:</strong> Zamanlanmış Görev Dosyası Yok";
$l['task_backup_cannot_write_backup'] = "<strong>Hata:</strong> Veritabanı Yedeğinizin Yazma İzni Olmadığından Yedekleme Klasörüne Kayıt Edilemedi.";
$l['task_backup_ran'] = "Veritabanı Yedekleme İşleminiz Başarılı Bir şekilde Bitmiştir.";
$l['task_checktables_ran'] = "Tabloların Kontrolü Başarılı Bir şekilde Bitmiştir.";
$l['task_checktables_ran_found'] = "<strong>Bildiri:</strong> Tabloların Kontrolü Başarılı Bir şekilde Bitti ve {1} Tablo'lar Başarıyla Optimize Edilmiştir.";
$l['task_dailycleanup_ran'] = "Günlük Temizlik İşlemi Başarılı Bir şekilde Tamamlandı.";
$l['task_hourlycleanup_ran'] = "Saatlik Temizlik İşlemi Başarılı Bir şekilde Tamamlandı.";
$l['task_logcleanup_ran'] = "Günlük Kayıt Görevi Başarıyla Tamamlandı.";
$l['task_promotions_ran'] = "Günlük Promosyon işlemleri Başarıyla Tamamlandı.";
$l['task_threadviews_ran'] = "Günlük Konu Temizleme işlemi Başarıyla Tamamlandı.";
$l['task_usercleanup_ran'] = "Günlük Üye Temizleme işlemi Başarıyla Tamamlandı.";
$l['task_userpruning_ran'] = "Kullanıcı Ayıklama Görevi Başarıyla Tamamlandı.";
$l['task_delayedmoderation_ran'] = "Gecikmiş Moderatör Görevi Başarıyla Tamamlandı.";
$l['task_massmail_ran'] = "Günlük E-posta Temizleme işlemi Başarıyla Tamamlandı.";
$l['task_massmail_ran_errors'] = "Gönderme Esnasında Bir veya Daha Fazla Sorunlar Oluştu\"{1}\":
{2}";
$l['task_versioncheck_ran'] = "Sürüm kontrolü görevi başarıyla çalıştırıldı.";
$l['task_versioncheck_ran_errors'] = "Sürüm kontrolü için MyBB'ye bağlanılamadı.";
$l['task_recachestylesheets_ran'] = 'Önbelleğe alınmış {1} stil sayfası.';

$l['dismiss_notice'] = "Bu bildirimi reddet";

$l['next'] = "Next";
$l['previous'] = "Previous";
$l['delete'] = "Delete";

$l['massmail_username'] = "Kullanıcı Adı";
$l['email_addr'] = "E posta adresi";
$l['board_name'] = "Forum İsmi";
$l['board_url'] = "Forum Adresi";

$l['comma'] = ", ";

$l['debug_generated_in'] = "Oluşturma tarihi {1}";
$l['debug_weight'] = "({1}% PHP / {2}% {3})";
$l['debug_sql_queries'] = "SQL Sorguları: {1}";
$l['debug_server_load'] = "Sunucu Yükü: {1}";
$l['debug_memory_usage'] = "Hafıza kullanımı: {1}";
$l['debug_advanced_details'] = "Gelişmiş Ayrıntılar";

$l['error_emailflooding_1_second'] = "Maalesef, her birinde yalnızca bir e-posta gönderebilirsiniz {1} dakika. Lütfen bir tane daha bekle 1 tekrar e-posta göndermeyi denemeden önce.";
$l['error_emailflooding_seconds'] = "Maalesef, her birinde yalnızca bir e-posta gönderebilirsiniz {1} dakika. Lütfen bir tane daha bekle {2} tekrar e-posta göndermeyi denemeden önce.";
$l['error_emailflooding_1_minute'] = "Maalesef, her birinde yalnızca bir e-posta gönderebilirsiniz {1} dakika. Lütfen bir tane daha bekle 1 tekrar e-posta göndermeye başlamadan önce dakika.";
$l['error_emailflooding_minutes'] = "Maalesef, her birinde yalnızca bir e-posta gönderebilirsiniz {1} dakika. Lütfen bir tane daha bekle {2} tekrar e-posta göndermeye başlamadan önce dakika.";
$l['error_invalidfromemail'] = "E-posta adresinden geçerli bir adres girmediniz.";
$l['error_noname'] = "Geçerli bir isim girmediniz.";
$l['your_email'] = "E-posta adresiniz:";
$l['email_note'] = "E-posta adresinizi buraya girin.";
$l['your_name'] = "Adınız:";
$l['name_note'] = "İsminizi buraya girin.";

$l['january'] = "Ocak";
$l['february'] = "Şubat";
$l['march'] = "Mart";
$l['april'] = "Nisan";
$l['may'] = "Mayıs";
$l['june'] = "Haziran";
$l['july'] = "Temmuz";
$l['august'] = "Ağustos";
$l['september'] = "Eylül";
$l['october'] = "Ekim";
$l['november'] = "Kasım";
$l['december'] = "Aralık";

$l['moderation_forum_attachments'] = "Bu forumdaki yeni eklerin görünür olmadan önce bir moderatör tarafından onaylanması gerektiğini lütfen unutmayın.";
$l['moderation_forum_posts'] = "Bu forumdaki yeni yayınların görünür olmadan önce bir moderatör tarafından onaylanması gerektiğini lütfen unutmayın.";
$l['moderation_user_posts'] = "Yaptığınız yeni yayınların görünür olmadan önce bir moderatör tarafından onaylanması gerektiğini lütfen unutmayın.";
$l['moderation_forum_thread'] = "Lütfen bu forumdaki yeni konuların görünür olmadan önce bir moderatör tarafından onaylanması gerektiğini unutmayın.";
$l['moderation_forum_edits'] = "Bu forumdaki düzenlenen yayınların görünür olmadan önce bir moderatör tarafından onaylanması gerektiğini lütfen unutmayın.";
$l['moderation_forum_edits_quick'] = "Bu forumdaki düzenlenen yayınların görünür olmadan önce bir moderatör tarafından onaylanması gerektiğini lütfen unutmayın.";
$l['awaiting_message_link'] = " <a href=\"{1}/{2}/index.php?module=user-awaiting_activation\">ACP'ye gidin</a>.";
$l['awaiting_message_single'] = "Etkinleştirilmeyi bekleyen 1 hesap var. Lütfen kullanıcıyı etkinleştirmek için ACP'nize gidin.";
$l['awaiting_message_plural'] = "Etkinleştirmeyi bekleyen {1} hesap var. Kullanıcıları etkinleştirmek için lütfen ACP'nize gidin.";

$l['select2_match'] = "Bir sonuç kullanılabilir, seçmek için enter tuşuna basın.";
$l['select2_matches'] = "{1} sonuçlar mevcuttur, gezinmek için yukarı ve aşağı ok tuşlarını kullanın.";
$l['select2_nomatches'] = "Hiçbir sonuç bulunamadı";
$l['select2_inputtooshort_single'] = "Lütfen bir veya daha fazla karakter girin";
$l['select2_inputtooshort_plural'] = "Lütfen {1} veya daha fazla karakter girin";
$l['select2_inputtoolong_single'] = "Lütfen bir karakter silin";
$l['select2_inputtoolong_plural'] = "Lütfen {1} karakteri silin";
$l['select2_selectiontoobig_single'] = "Yalnızca bir öğe seçebilirsiniz";
$l['select2_selectiontoobig_plural'] = "Yalnızca {1} öğe seçebilirsiniz";
$l['select2_loadmore'] = "Daha fazla sonuç yükleniyor ve hellip;";
$l['select2_searching'] = "Arıyor & hellip;";

$l['stopforumspam_error_decoding'] = 'Kaynağındaki verilerin kodu çözülürken hata oluştu StopForumSpam.com.';
$l['stopforumspam_error_retrieving'] = 'Sitesinden veri alınırken hata oluştu StopForumSpam.com.';
$l['stopforumspam_invalid_email'] = 'Şunu kontrol ederken geçersiz e-posta adresi: StopForumSpam.com API.';
$l['stopforumspam_invalid_ip_address'] = 'IP adresini kontrol ederken geçersiz IP adresi StopForumSpam.com API.';

$l['sfs_error_username'] = 'Kullanıcı Adı';
$l['sfs_error_ip'] = 'IP Adres';
$l['sfs_error_email'] = 'E posta';
$l['sfs_error_or'] = 'veya';

$l['boardclosed_reason'] = 'Bu forumlar şu anda bakım nedeniyle kapalıdır. Lütfen daha sonra tekrar kontrol edin';
