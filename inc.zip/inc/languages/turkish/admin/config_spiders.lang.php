﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['spiders_bots'] = "Örümcek Botlar";
$l['spiders_bots_desc'] = "Bu kısım, arama motoru örümceklerinin otomatik olarak tespiti ve yönetimine olanak sağlar. Ayrıca örümcek botların forumunuzu son ziyaret ettikleri zamanlarıda yine bu kısımdan takip edebilirsiniz.";
$l['add_new_bot'] = "Yeni Bot Ekle";
$l['add_new_bot_desc'] = "Bu Kısımdan, forumunuz için tespit edilecek yeni bir Örümcek Bot ekleyebilirsiniz.";

$l['edit_bot'] = "Örümcek Bot Düzenle";
$l['edit_bot_desc'] = "Bu Kısımdan, seçmiş olduğunuz botu düzenleyebilirsiniz.";

$l['bot'] = "Mevcut Örümcek Botlar";
$l['last_visit'] = "Son Ziyareti";
$l['no_bots'] = "Şu an forumuna eklenmiş herhangi bir Örümcek Bot mevcut değil.";

$l['name'] = "Örümcek Bot İsmi";
$l['name_desc'] = "Eklemek istediğiniz Örümcek Bot için forumda görünecek bir isim giriniz.";
$l['user_agent'] = "Bot Aracı Bağlantısı";
$l['user_agent_desc'] = "Bot aracı ile uyuşabilen bağlantıyı, (User Agent String) giriniz. (Kısmen uyuşanlar kabul edilir)";
$l['language_str'] = "Dil Ayarları";
$l['language_desc'] = "Örümcek Botun forumunuzu görüntelemesini istediğiniz Dili seçiniz.";
$l['theme'] = "Tema Ayarları";
$l['theme_desc'] = "Örümcek Botun forumunuzu görüntelemesini istediğiniz Temayı seçiniz.";
$l['user_group'] = "Grup Ayarları";
$l['user_group_desc'] = "Örümcek Botları için uygulanmasını istediğiniz Kullanıcı grubunu seçiniz. (Not: Örümcek botlar için varsayılan kullanıcı grubunu değiştirmeniz önerilmez).";
$l['save_bot'] = "Örümcek Botu Kaydet";
$l['use_board_default'] = "Varsayılan Forum Ayarlarını Kullan";

$l['error_invalid_bot'] = "Belirtmiş olduğunuz Örümcek Bot bulunamadı.";
$l['error_missing_name'] = "Bu Örümcek Bot için bir isim belirtmediniz.";
$l['error_missing_agent'] = "Bu Örümcek Bot için uyuşabilen bir ''Bot Aracı Bağlantısı'' belirtmediniz.";

$l['success_bot_created'] = "Örümcek Bot başarılı olarak oluşturuldu.";
$l['success_bot_updated'] = "Örümcek Bot başarılı olarak güncellendi.";
$l['success_bot_deleted'] = "Seçmiş olduğunuz Örümcek Bot başarılı olarak silindi.";

$l['confirm_bot_deletion'] = "Bu Örümcek Botu Silmek İstediğinizden Emin Misiniz?";

