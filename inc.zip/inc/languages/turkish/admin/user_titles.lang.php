﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['user_titles'] = "Kullanıcı Başlıkları";
$l['user_titles_desc'] = "Bu kısımdan, mevcut kullanıcı başlıklarını yönetebilirsiniz. Kullanıcı başlıkları mesaj sayısına bağlı olarak rütbelendirilir ve ayrıca kullanıcının sahip olduğu mesaj sayısına bağlı olarak 'Yıldız' resmi göstermenize olanak sağlar.";
$l['add_new_user_title'] = "Yeni Kullanıcı Başlığı Ekle";
$l['add_new_user_title_desc'] = "Bu kısımdan, yeni bir kullanıcı başlığı ekleyebilirsiniz. <strong>Not:</strong> <i>Bu işlem, <u><a href=\"index.php?module=user-group_promotions\">Promosyon Sistemi (Terfi Grupları Özelliği)</a></u> değildir.</i>";

$l['error_missing_title'] = "Bu kullanıcı başlığı için başlık girmediniz";
$l['error_missing_posts'] = "Bu kullanıcı başlığı için minimum mesaj sayısını girmediniz";
$l['error_cannot_have_same_posts'] = "Bu kullanıcı başlığı, başka bir başlık ile aynı mesaj sayısında olamaz.";
$l['error_invalid_user_title'] = "Geçersiz bir kullanıcı başlığı girdiniz";

$l['success_user_title_created'] = "Yeni kullanıcı başlığı, başarılı bir şekilde oluşturuldu.";
$l['success_user_title_updated'] = "Kullanıcı başlığı, başarılı bir şekilde güncellendi.";
$l['success_user_title_deleted'] = "Seçilen kullanıcı başlığı, başarılı bir şekilde silindi.";

$l['title_to_assign'] = "Atanacak Başlık";
$l['title_to_assign_desc'] = "Eğer kişisel başlık seçilmemişse, bu başlık kullanıcı adının altında gösterilecektir.";
$l['minimum_posts'] = "Minimum Mesaj";
$l['minimum_posts_desc'] = "Kullanıcıya; kullanıcı başlığı belirlenmeden önce, kullanıcının sahip olması gereken minimum mesaj sayısıdır.";
$l['number_of_stars'] = "Yıldız Sayısı";
$l['number_of_stars_desc'] = "Bu kullanıcı başlığının altında gösterilecek yıldız sayısını girin. Yıldız koymak istemiyorsanız 0 olarak ayarlayın.";
$l['star_image'] = "Yıldız Resmi";
$l['star_image_desc'] = "Şayet bu kullanıcı başlığı yıldız gösterecekse, yıldız resminin adresini girin. Eğer boşsa, kullanıcı grubu yıldızı resmi gösterilecek. şu anki {theme} kullanıcıları için resim klasörü yolunu belirtin.";
$l['save_user_title'] = "Kullanıcı Başlığını Kaydet";
$l['edit_user_title'] = "Kullanıcı Başlığını Düzenle";
$l['edit_user_title_desc'] = "Bu kısım kullanıcı başlığını yönetmenize izin verir.";
$l['user_title_deletion_confirmation'] = "Bu kullanıcı başlığını silmek istediğinizden emin misiniz?";
$l['manage_user_titles'] = "Kullanıcı Başlıkları";
$l['user_title'] = "Kullanıcı Başlığı";
$l['no_user_titles'] = "Şu anda oluşturulmuş hiçbir kullanıcı başlığı mevcut değil.";

