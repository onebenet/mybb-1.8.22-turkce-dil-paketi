﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['mod_logs'] = "Moderatör Kayıtları";
$l['mod_logs_desc'] = "Bu kısımdan, forum moderatörlerinin yapım oldukları tüm işlem kayıtlarını görüntüleyebilir ve aratabilirsiniz. Bu kayıtlar, herhangi bir kullanıcının yaptığı işlemleri, (kendi yorumlarını/konularını/ek dosyalarını silmelerini) ve moderatörlerin tüm işlemlerini içerir.";
$l['prune_mod_logs'] = "Moderatör Kayıtlarını Ayıkla";
$l['prune_mod_logs_desc'] = "Bu kısımdan, Seçilen seçeneklere bağlı olarak Moderatör ve/veya Kullanıcıların yapmış oldukları tüm işlem kayıtlarını ayıklayabilirsiniz.";

$l['no_modlogs'] = "Seçilen kriterlere uygun herhangi bir kayıt bulunamadı.";

$l['username'] = "Kullanıcı Adı";
$l['date'] = "Tarih";
$l['action'] = "Yapılan İşlem";
$l['information'] = "Açıklama";
$l['ipaddress'] = "IP Adresi";

$l['forum'] = "Forum:";
$l['thread'] = "Konu:";
$l['post'] = "Yorum:";
$l['user_info'] = "Kullanıcı:";
$l['announcement'] = "Duyuru:";

$l['filter_moderator_logs'] = "Moderatör Kayıtlarını Filtrele";
$l['forum_moderator'] = "Moderatör Seç:";
$l['sort_by'] = "Listeleme Metodu Seç:";
$l['results_per_page'] = "Sayfa Başına Gösterilecek Sonuç:";
$l['all_moderators'] = "Tüm Moderatörler";
$l['older_than'] = "";

$l['forum_name'] = "Forum Adı";
$l['thread_subject'] = "Konu Başlığı";

$l['asc'] = "Artan";
$l['desc'] = "Azalan";

$l['in'] = "-";
$l['order'] = "";
$l['days'] = "Günden daha eski kayıtlar";

$l['prune_moderator_logs'] = "Moderatör Kayıtlarını Ayıkla";
$l['date_range'] = "Tarih Aralığı:";

$l['success_pruned_mod_logs'] = "Moderatör kayıtları, başarılı olarak ayıklandı.";
$l['note_logs_locked'] = "Güvenlik gereği, 24 saatten daha az bir süre içerisinde oluşturulan kayıtlar ayıklanamaz.";

