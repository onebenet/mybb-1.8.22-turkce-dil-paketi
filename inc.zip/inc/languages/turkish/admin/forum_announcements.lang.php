﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['forum_announcements'] = "Forum Duyuruları";
$l['forum_announcements_desc'] = "Bu kısımdan, forumunuz için eklemiş olduğunuz genel ve bireysel duyuruları yönetebilirsiniz.";
$l['add_announcement'] = "Duyuru Ekle";
$l['add_announcement_desc'] = "Bu kısımdan, forumunuz için genel ve bireysel duyurular ekleyebilirsiniz.<br />Genel duyurular tüm forumlarda gösterilir, bireysel duyurular ise seçmiş olduğunuz forum ve alt forumlarda gösterilir.";
$l['update_announcement'] = "Duyuruyu Güncelle";
$l['preview_announcement'] = "Duyuruyu Önizle";
$l['update_announcement_desc'] = "Bu kısımdan seçmiş olduğunuz duyurunun ayarlarını güncelleyebilirsiniz.";

$l['start_date_desc'] = "(GMT), Tarih ve Saat ayarlarına göre eklemeye çalıştığınız duyuru, seçmiş olduğunuz forumlarda gösterilecektir.";
$l['end_date_desc'] = "Bu duyuru, (GMT) Tarih ve Saat ayarlarına göre gösterimde kalacaktır.<br />Dilerseniz bu duyurunun silinmemesi ve kalıcı olması için aşağıdaki <b>Hiçbir Zaman</b> seçeneğini seçebilirsiniz.";
$l['forums_to_appear_in_desc'] = "Bu duyuru, aşağıda seçmiş olduğunuz forumlarda gösterilecektir. Bu duyuru seçmiş olduğunuz forum ve alt forumlarınıda kapsamaktadır.";

$l['announcement'] = "Duyurular";
$l['global_announcements'] = "Genel Duyurular";

$l['no_global_announcements'] = "Şu anda eklenmiş herhangi bir genel duyuru bulunamadı.";
$l['no_forums'] = "Forum duyurularını göstermek için sitenizde açılmış herhangi bir forum bulunamadı.";

$l['confirm_announcement_deletion'] = "Bu duyuruyu silmek istediğinizden emin misiniz?";

$l['success_announcement_deleted'] = "Seçmiş olduğunuz duyuru başarılı olarak silindi.";
$l['success_added_announcement'] = "Eklemiş olduğunuz duyuru başarılı olarak oluşturuldu.";
$l['success_updated_announcement'] = "Seçmiş olduğunuz duyuru başarılı olarak güncellendi.";

$l['error_invalid_announcement'] = "Lütfen geçerli bir duyuru giriniz.";
$l['error_missing_title'] = "Duyuru için herhangi bir başlık girmediniz.";
$l['error_missing_message'] = "Duyuru için yayınlanması gereken içeriği (mesajı) girmediniz.";
$l['error_missing_forum'] = "Duyuru için bir forum seçmediniz.";
$l['error_invalid_start_date'] = "Duyuru için başlangıç ​​tarihi geçersiz.";
$l['error_invalid_end_date'] = "Duyuru için bitiş tarihi geçersiz.";
$l['error_end_before_start'] = "Bitiş tarihi başlangıç ​​tarihinden sonra olmalıdır.";
$l['add_an_announcement'] = "Yeni Bir Duyuru Ekle";
$l['update_an_announcement'] = "Duyuruyu Güncelle";
$l['save_announcement'] = "Duyuruyu Kaydet";
$l['title'] = "Duyuru Başlığı";
$l['start_date'] = "Duyurunun Başlangıç Tarihi";
$l['end_date'] = "Duyurunun Bitiş Tarihi";
$l['message'] = "Duyuru İçeriği";
$l['forums_to_appear_in'] = "Duyurunun Gösterileceği Forum-(lar)";
$l['allow_html'] = "[HTML] Kod Kullanılsın Mı?";
$l['allow_mycode'] = "[MyKod] Tagları Kullanılsın Mı?";
$l['allow_smilies'] = "(İfadeler) Kullanılsın Mı?";
$l['time'] = "Tarih & Saat:";
$l['set_time'] = "Tarih & Saat Ayarları";

$l['announcement_preview'] = 'Duyuru Önizlemesi';
