﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

// Tabs
$l['moderation_queue'] = "Moderasyon İşlemi Bekleyenler";
$l['threads'] = "Konular";
$l['threads_desc'] = "Bu kısımdan, Moderasyon işlemi bekleyen Konuları görüntüleyebilir, onaylayabilir ve yönetebilirsiniz.";
$l['posts'] = "Yorumlar";
$l['posts_desc'] = "Bu kısımdan, Moderasyon işlemi bekleyen Yorumları görüntüleyebilir, onaylayabilir ve yönetebilirsiniz.";
$l['attachments'] = "Ekli Dosyalar";
$l['attachments_desc'] = "Bu kısımdan, Moderasyon işlemi bekleyen Ekli Dosyaları görüntüleyebilir, onaylayabilir ve yönetebilirsiniz.";
$l['threads_awaiting_moderation'] = "Moderasyon İşlemi Bekleyen Konular";
$l['posts_awaiting_moderation'] = "Moderasyon İşlemi Bekleyen Yorumlar";
$l['attachments_awaiting_moderation'] = "Moderasyon İşlemi Bekleyen Ekli Dosyalar";

// Errors
$l['error_no_posts'] = "Moderasyon İşlemi Bekleyen Yorum Yok.";
$l['error_no_attachments'] = "Moderasyon İşlemi Bekleyen Ek Dosya Yok.";
$l['error_no_threads'] = "Şu Anda Moderasyon İşlemi Bekleyen Konu, Yorum ve Ek Dosya Yok.";

// Success
$l['success_threads'] = "Seçilen Konulara Başarılı Bir Şekilde Moderasyon İşlemi Uygulandı.";
$l['success_posts'] = "Seçilen Yorumlara Başarılı Bir Şekilde Moderasyon İşlemi Uygulandı.";
$l['success_attachments'] = "Seçilen Ekli Dosyalara Başarılı Bir Şekilde Moderasyon İşlemi Uygulandı.";

// Pages
$l['subject'] = "Başlık";
$l['author'] = "Yazar";
$l['posted'] = "Gönderildi";
$l['ignore'] = "Yoksay";
$l['approve'] = "Onayla";
$l['forum'] = "Forum:";
$l['thread'] = "Konu:";
$l['post'] = "Yorum:";
$l['re'] = "CVP:";
$l['filename'] = "Dosya Adı";
$l['uploadedby'] = "Yükleyen:";
$l['controls'] = "Kontroller";

// Buttons
$l['mark_as_ignored'] = "Tümünü Yoksayı İşaretle";
$l['mark_as_deleted'] = "Tümünü Sili İşaretle";
$l['mark_as_approved'] = "Tümünü Onaylayı İşaretle";
$l['perform_action'] = "Seçimleri Uygula";

