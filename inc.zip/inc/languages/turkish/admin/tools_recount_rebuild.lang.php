﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['recount_rebuild'] = "Sayım & Yapılandırmalar";
$l['recount_rebuild_desc'] = "Bu kısımdan, Forumunuzdaki oluşan senkronizasyon hataları için verilerinizi yeniden yapılandırabilir ve saydırabilirsiniz.";

$l['data_per_page'] = "Sayfa Başına Veri Sayımı";
$l['recount_stats'] = "Forum İstatistik Sayaçları Güncelle";
$l['recount_stats_desc'] = "Bu araç, forum index ve istatistikler sayfasındaki, İstatistik (bilgilerini) sayaçlarını güncellemenizi sağlar.";
$l['recount_reputation'] = "Rep Puanı Sayaçlarını Güncelle";
$l['recount_reputation_desc'] = "Bu araç, kullanıcıların Rep Puanı, (sayılarını) sayaçlarını güncellemenizi sağlar.";
$l['recount_warning'] = "Uyarı Puanı Sayaçlarını Güncelle";
$l['recount_warning_desc'] = "Bu araç, kullanıcıların Uyarı Puanı, (seviyelerini) sayaçlarını güncellemenizi sağlar.";
$l['recount_private_messages'] = "Özel Mesaj Sayaçlarını Güncelle";
$l['recount_private_messages_desc'] = "Bu araç, kullanıcıların Özel Mesaj, (sayılarını) sayaçlarını güncellemenizi sağlar.";
$l['recount_referrals'] = "Referans Sayaçlarını Güncelle";
$l['recount_referrals_desc'] = "Bu araç, kullanıcıların Referans, (sayılarını) sayaçlarını güncellemenizi sağlar.";
$l['recount_thread_ratings'] = "Konu Oyları Sayaçlarını Güncelle";
$l['recount_thread_ratings_desc'] = "Bu araç, Konulara verilen Oyların sayaçlarını güncellemenizi sağlar.";
$l['rebuild_forum_counters'] = "Forum Sayaçlarını Güncelle";
$l['rebuild_forum_counters_desc'] = "Bu araç, Forumda açılan tüm ''Yeni Konu'' ve ''Yazılan Yeni Yorumlar'' için konu ve yorum sayısı sayaçlarını güncellemenizi sağlar.";
$l['rebuild_poll_counters'] = "Anket Sayaçlarını Güncelle";
$l['rebuild_poll_counters_desc'] = "Bu araç, Forumda başlatılan tüm Anketlerde, verilen oy sayısı sayaçlarını güncellemenizi sağlar.";
$l['rebuild_thread_counters'] = "Konu Görüntüleme/Okunma Sayaçlarını Güncelle";
$l['rebuild_thread_counters_desc'] = "Bu araç, Forumda açılan tüm Konuların görüntülenme/okunma sayısı sayaçlarını güncellemenizi sağlar.";
$l['recount_user_posts'] = "Kullanıcıların Yorum Sayaçlarını Güncelle";
$l['recount_user_posts_desc'] = "Bu araç, Kullanıcıların (postbit ve profil sayfalarındaki) Yorum sayısı sayaçlarını güncellemenizi sağlar.";
$l['recount_user_threads'] = "Kullanıcıların Konu Sayaçlarını Güncelle";
$l['recount_user_threads_desc'] = "Bu araç, Kullanıcıların (postbit ve profil sayfalarındaki) Konu sayısı sayaçlarını güncellemenizi sağlar.";
$l['rebuild_attachment_thumbs'] = "Ek Dosya Tırnaklarını Güncelle";
$l['rebuild_attachment_thumbs_desc'] = "Bu araç, Ekli Dosyaların genişlik ve yükseklik değerleri ile eksik Ek Dosya Tırnakları mevcut ise eksiklerini giderip güncellemenizi sağlar.";

$l['success_rebuilt_forum_counters'] = "Forum sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_thread_counters'] = "Konu Görüntüleme/Okunma sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_poll_counters'] = "Anket sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_user_post_counters'] = "Kullanıcıların Yorum sayısı sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_user_thread_counters'] = "Kullanıcıların Konu sayısı sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_attachment_thumbnails'] = "Ek Dosya Tırnakları başarılı olarak güncellendi.";
$l['success_rebuilt_forum_stats'] = "Forum İstatistik sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_reputation'] = "Kullanıcıların Rep Puanı sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_warning'] = "Kullanıcıların Uyarı Puanı sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_private_messages'] = "Kullanıcıların Özel Mesaj sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_referral'] = "Kullanıcıların Referans Sayısı sayaçları başarılı olarak güncellendi.";
$l['success_rebuilt_thread_ratings'] = "Konu Oyları sayaçları başarılı olarak güncellendi.";

$l['confirm_proceed_rebuild'] = "Sayım & yapılandırma işlemine devam etmek için lütfen,  ''Devam Et'' butonuna tıklayın.";
$l['automatically_redirecting'] = "Otomatik Olarak Yönlendiriliyorsunuz...";

