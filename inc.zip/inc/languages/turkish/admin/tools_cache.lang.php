﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['cache'] = "Önbellek:";
$l['cache_manager'] = "Önbellek Yönetimi";
$l['cache_manager_description'] = "Bu kısımdan, MyBB optimizasyonu için kullanılan önbellek sistemini yönetebilirsiniz. Önbelleği yeniden güncellemek, güncellemede ve yeniden senkronize etmekte kullanılacak gerekli verilerin en son halini alacaktır. Yeni bir önbellek yüklemesi, önbelleği seçilen önbellek işleyiciye, (disk, eAccelerator, memcache, etc) yükleyecektir. Veritabanı veya dosya XCache sistemi, eAccelerator, ya da başka bir önbellek işleyice geçildiğinde tüm önbelleği yeniden yükleme/yapılandırma ve güncelleme yapmak yararlı ve kullanışlıdır.";
$l['rebuild_cache'] = "Önbelliği Yapılandır";
$l['reload_cache'] = "Önbelliği Güncelle";
$l['rebuild_reload_all'] = "[Tümünü Yeniden Yapılandır & Güncelle]";

$l['error_cannot_rebuild'] = "Bu önbellek yeniden yapılandırılamaz.";
$l['error_empty_cache'] = "Önbellek boş.";
$l['error_incorrect_cache'] = "Yanlış önbellek seçimi.";
$l['error_no_cache_specified'] = "Görüntülemek için bir önbellek belirtmediniz.";

$l['success_cache_rebuilt'] = "Önbellek başarıyla yapılandırıldı.";
$l['success_cache_reloaded'] = "Önbellek başarıyla güncellendi.";

