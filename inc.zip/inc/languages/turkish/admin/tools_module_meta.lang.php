﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['tools_and_maintenance'] = "Araçlar & Bakım";

$l['maintenance'] = "Bakım";
$l['logs'] = "Sistem Kayıtları";

$l['system_health'] = "<img src=\"../images/admincp/sistem.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Sistem Durumu";
$l['cache_manager'] = "<img src=\"../images/admincp/arac-2.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Önbellek Yönetimi";
$l['task_manager'] = "<img src=\"../images/admincp/gorevler.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Görev Yöneticisi";
$l['recount_and_rebuild'] = "<img src=\"../images/admincp/arac-2.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Sayım &amp; Yapılandırma";
$l['view_php_info'] = "<img src=\"../images/admincp/php.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> PHP Bilgileri";
$l['database_backups'] = "<img src=\"../images/admincp/veritabani-y.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Veritabanı Yedekleri";
$l['optimize_database'] = "<img src=\"../images/admincp/veritabani-o.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Veritabanı Optimize";
$l['file_verification'] = "<img src=\"../images/admincp/dosya-d.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Dosya Doğrulaması";

$l['administrator_log'] = "<img src=\"../images/admincp/admin.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Admin Kayıtları";
$l['moderator_log'] = "<img src=\"../images/admincp/moderator.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Moderatör Kayıtları";
$l['user_email_log'] = "<img src=\"../images/admincp/k-posta.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Kullanıcı E-Posta Kayıtları";
$l['system_mail_log'] = "<img src=\"../images/admincp/s-posta.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Sistem E-Posta Kayıtları";
$l['user_warning_log'] = "<img src=\"../images/admincp/uyari.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Uyarı Kayıtları";
$l['statistics'] = "<img src=\"../images/admincp/istatistik.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Forum İstatistikleri";
$l['spam_log'] = "<img src=\"../images/admincp/spam.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Spam Kayıtları";

$l['can_access_system_health'] = "Sistem Durumuna Erişebilir Mi?";
$l['can_manage_cache'] = "Önbelleği Yönetebilir Mi?";
$l['can_manage_tasks'] = "Zamanlanmış Görevleri Yönetebilir Mi?";
$l['can_manage_db_backup'] = "Veritabanı Yedeklerini Yönetebilir Mi?";
$l['can_optimize_db'] = "Veritabanı Optimizasyonlarını Yönetebilir Mi?";
$l['can_recount_and_rebuild'] = "Yeniden Sayım ve Yapılandırma Yapabilir Mi?";
$l['can_manage_admin_logs'] = "Admin Kayıtlarını Yönetebilir Mi?";
$l['can_manage_mod_logs'] = "Moderatör Kayıtlarını Yönetebilir Mi?";
$l['can_manage_user_mail_log'] = "Kullanıcı E-Posta Kayıtlarını Yönetebilir Mi?";
$l['can_manage_system_mail_log'] = "Sistem E-Posta Kayıtlarını Yönetebilir Mi?";
$l['can_manage_user_warning_log'] = "Kullanıcı Uyarı Kayıtlarını Yönetebilir Mi?";
$l['can_manage_spam_log'] = "Spam Kayıtlarını Yönetebilir Mi?";
$l['can_view_php_info'] = "PHP Bilgileri Görüntüleyebilir Mi?";
$l['can_manage_file_verification'] = "Dosya Sistemi Doğrulamasını Yönetebilir Mi?";
$l['can_view_statistics'] = "İstatistikleri Görüntüleyebilir Mi?";

