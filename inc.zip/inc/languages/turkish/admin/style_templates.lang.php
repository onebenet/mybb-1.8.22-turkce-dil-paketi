﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['template_sets'] = "Şablon Setleri";
$l['template_set'] = "Şablon Setleri Listesi";
$l['templates'] = "{1} Şablonlar";

$l['manage_template_sets'] = "Şablonları Yönet";
$l['manage_template_sets_desc'] = "Bu kısımdan, mevcut veya özelleştirmek istediğiniz tüm şablon setleri listesini görebilir ve yönetebilirsiniz.";
$l['add_set'] = "Yeni Set Ekle";
$l['add_set_desc'] = "Bu kısımdan, yeni bir şablon seti oluşturabilirsiniz. Yeni bir şablon seti diğer şablon setlerinize müdahele etmeden düzenlemenize ve bir nevi kopyasını oluşturmanızada olanak sağlar.";
$l['add_template'] = "Yeni Şablon Ekle";
$l['add_template_desc'] = "Bu kısımdan, yeni bir şablon oluşturabilirsiniz.";
$l['add_template_group'] = "Yeni Şablon Grubu Ekle";
$l['add_template_group_desc'] = "Bu kısımdan, şablon karışıklıklarını önlemek için yeni bir ''Ana Şablon Grubu'' oluşturabilirsiniz.";
$l['search_replace'] = "Bul/Düzenle";
$l['search_replace_desc'] = "Bu araç şablon isimlerine göre arama yapmanıza olanak sağlar ve bazı metin düzenlemeleri için  başka bir metni isteğe bağlı olarak değiştimenizede olanak sağlar.";
$l['find_updated'] = "Güncelleştirilmiş Şablonları Bul";
$l['find_updated_desc'] = "MyBB'nin yeni bir versiyonunu yüklediğiniz zaman, güncelleştirilmiş şablonları bulmanıza olanak sağlar. Bu sayede değişen şablonları kolayca bulabilir ve kendinize göre düzenleyebilirsiniz.";
$l['edit_template'] = "Düzenlenen Şablon";
$l['editing_template'] = "Düzenlenen Şablon: {1}";
$l['edit_template_desc'] = "Bu kısımdan, şablon setini, kodlarını ve başlığını kolay bir şekilde düzenleyebilirsiniz.";
$l['edit_set'] = "Şablon Setini Düzenle";
$l['edit_set_desc'] = "Bu kısımdan, seçmiş olduğunuz şablonun set özelliklerini düzenleyebilirsiniz.";
$l['manage_templates'] = "Şablon Yönetimi";
$l['manage_templates_desc'] = "Bu kısımdan, düzenlemek istediğiniz şablonun adına tıklayıp veya sağ taraftaki <b>''Seçenekler''</b> sekmesinden <b>''Genişlet''</b>i seçerek bağlı olduğu alt şablonları açabilir ve özelleştirmelerinizi yapabilirsiniz.<br />Ayrıca yine bu kısımda, sizin için en önemli ve en çok özelleştirme yapılabilecek şablon setlerini numara sistemi kullanarak ve önemli olanlarıda <span style=\"color: rgb(0, 128, 0);\"><b>yeşil</b></span> renk ile vurgulayıp ilk sıralarda yer almasını sağladık. Bu sayede en çok düzenleme yapılan şablon setlerini zahmetsiz bir şekilde bulup düzenleyebileceksiniz.";
$l['diff_report'] = "Farkları Göster";
$l['diff_report_desc'] = "Bu kısımdan, şablonlarda yapmış olduğunuz değişiklik ve özelliştirmelerin arasındaki farkları analiz edebilir ve şablonun bir önceki hali ile editlenmiş halinin farklarını veya hatalarınızı tespit edebilirsiniz.";

$l['title'] = "Başlık";
$l['save'] = "Kaydet";
$l['search_for'] = "Ara/Bul";
$l['replace_with'] = "Düzenle (İsteğe Bağlı)";
$l['reset'] = "Sıfırla";
$l['find_templates'] = "Şablonları Bul";
$l['find_and_replace'] = "Bul ve Düzenle";
$l['search_template_names'] = "Şablon Başlıklarını Ara";
$l['ungrouped_templates'] = "<span style=\"color: rgb(128, 0, 0);\">*</span> Headerinclude - <span style=\"color: rgb(0, 128, 0);\">[Gruplandırılmamış]</span> Şablonlar";

$l['search_noneset'] = "Aramak için bir dizge girmediniz.";
$l['search_results'] = "Şablon Arama Sonuçları";
$l['search_header'] = "{2} içinde \"{1}\" Aranıyor...";
$l['search_updated'] = "{1} Güncellendi";
$l['search_found'] = "{1} Bulundu";
$l['search_created_custom'] = "{1} için özel şablon oluşturuldu";
$l['search_edit'] = "Düzenle";
$l['search_change_original'] = "Orjinal Haline Çevir";
$l['search_noresults'] = "'<strong>{1}</strong>' Dize içeren hiçbir şablon bulunamadı";
$l['search_noresults_title'] = "'<strong>{1}</strong>' Başlığı ile ilgili hiçbir şablon bulunamadı";
$l['default_templates'] = "Varsayılan Şablonlar";

$l['edit_template_breadcrumb'] = "Düzenlenen Şablon: ";

$l['global_templates'] = "Genel Şablonlar";
$l['master_templates'] = "Ana Şablonlar";

$l['not_used_by_any_themes'] = "Hiçbir tema için kullanılmıyor";
$l['used_by'] = "Kullanılan Tema: ";
$l['used_by_all_themes'] = "Tüm temalar için kullanılıyor";

$l['expand_templates'] = "Şablonu Genişlet";
$l['edit_template_set'] = "Şablon Setini Düzenle";
$l['delete_template_set'] = "Şablon Setini Sil";
$l['empty_template_set'] = "<em>Bu sette hiçbir şablon mevcut değil.</em>";

$l['inline_edit'] = "Satıriçi Düzenle";
$l['full_edit'] = "Tam Düzenle";
$l['revert_to_orig'] = "Orjinal Haline Çevir";
$l['delete_template'] = "Şablonu Sil";
$l['edit_in'] = "Düzenle";

$l['group_calendar'] = "Takvim Sayfası";
$l['group_forumdisplay'] = "5. Forum Görüntüleme - [forumdisplay]";
$l['group_index'] = "0. Ana Sayfa - [index]";
$l['group_error'] = "Hata Mesajı";
$l['group_memberlist'] = "Üye Listesi - [memberlist]";
$l['group_multipage'] = "Sayfa Numaralandırma - [multipage]";
$l['group_private'] = "Özel Mesajlaşma";
$l['group_portal'] = "1. Portal Sayfası";
$l['group_postbit'] = "7. Post Bit - [postbit]";
$l['group_posticons'] = "Başlık Sembolleri";
$l['group_showthread'] = "6. Konu Gösterimi - [showthread]";
$l['group_usercp'] = "Kullanıcı Kontrol Paneli";
$l['group_online'] = "Kimler Çevrimiçi";
$l['group_forumbit'] = "4. Forum Bit";
$l['group_editpost'] = "Mesaj Düzenleme";
$l['group_forumjump'] = "Hızlı Geçiş";
$l['group_moderation'] = "Moderasyon";
$l['group_nav'] = "9. Navigasyon";
$l['group_search'] = "Arama Sayfası";
$l['group_showteam'] = "Forum Yöneticileri - [showteam]";
$l['group_reputation'] = "Rep Puanı";
$l['group_newthread'] = "Yeni Konu";
$l['group_newreply'] = "Yeni Yorum";
$l['group_member'] = "8. Üye Profili";
$l['group_warning'] = "Uyarı Sistemi";
$l['group_global'] = "Global - [Bildirim]";
$l['group_header'] = "2. Header - [Üst Kısım]";
$l['group_managegroup'] = "Grup Yönetimi";
$l['group_misc'] = "Çeşitli - [misc]";
$l['group_modcp'] = "Moderatör Kontrol Paneli";
$l['group_announcement'] = "Duyuru";
$l['group_polls'] = "Anket";
$l['group_post'] = "Ek Dosya & Konu Ön Ek";
$l['group_printthread'] = "Konu Yazdırma";
$l['group_report'] = "Rapor Et";
$l['group_smilieinsert'] = "İfade Ekleyici";
$l['group_stats'] = "İstatistik";
$l['group_xmlhttp'] = "XMLHTTP";
$l['group_footer'] = "3. Footer - [Alt Kısım]";
$l['group_video'] = "Video MyKod";
$l['group_sendthread'] = "Konuyu Arkadaşına Gönder";
$l['group_mycode'] = "Mykod";

$l['expand'] = "Genişlet";
$l['collapse'] = "Daralt";

$l['save_continue'] = "Kaydet ve Düzenlemeye Devam Et";
$l['save_close'] = "Kaydet ve Şablon Listesine Dön";

$l['template_name'] = "Şablon İsmi";
$l['template_name_desc'] = "Varsayılan şablon adı. Varsayılan şablon adını değiştirecek olursanız, yeni adıyla özel şablon olarak kaydedilir.";
$l['template_set_desc'] = "Bu şablon setinde, hangi şablonu ayarlamak istiyorsunuz?";

$l['template_group_prefix'] = "Şablon Grubu için Bir (Ön Ek) Giriniz:";
$l['template_group_prefix_desc'] = "Yeni ''Grup Şablonu'' için bir (Ön Ek) isim/takı giriniz. Gireceğiniz bu ön ek var olmayan bir şablon grubu ön eki olmalıdır.<br /><strong>Örnek:</strong> Ön ekimiz <strong>ONEBE</strong> olsun, <strong>ONEBE</strong> adında bir ana şablon grubu oluşturduk diyelim, daha sonra bu ana şablon grubu içinde de <strong><em>ONEBE_DENEME</em></strong> adında <strong>''Yeni Şablon Ekle''</strong> kısmından alt şablonumuzu veya şablonlarımızı oluşturarak kendimize özel daha doğrusu temamıza özel  tıpkı Header ve Header şablonlarındaki alt şablonlar gibi bir şablon grubu oluşturmuş oluruz.<br />(Özel Karakterler Haricinde, Büyük/Küçük ve Türkçe Karakterli Harfler Kullanabilirsiniz).";
$l['template_group_title'] = "Şablon Grubu için Bir (Başlık) Giriniz:";
$l['template_group_title_desc'] = "Şablon Grupları listesinde görünecek olan bir başlık giriniz.<br /><strong>Örnek:</strong> <strong><em>MyBBGrup</em></strong> adında bir başlık kullanarak şablon grupları listesinde de <strong><em>MyBBGrup</em></strong> adı ile listelenmesini sağlayabilirsiniz. Başlığınız ön eki ile aynı olabilir fakat, ön ekinden farklı bir başlık kullanmanız karmaşalık oluşturmaması için tavsiye edilir. Burada dikkat edilmesi gereken nokta, <strong>''Yeni Şablon Ekle''</strong> kısmında şablon başlığı yerine şablon ekini girmenizdir. Kısaca, oluşturmak istediğiniz şablonun hangi ''şablon grubu altında'' listelenmesini istiyorsanız o grubun ön ekini girmeniz yeterlidir.<br />(Büyük/Küçük, Türkçe ve Özel Karakterli Harfler/Semboller Kullanabilirsiniz).";

$l['edit_template_group'] = "Şablon Grubunu Düzenle";
$l['editing_template_group'] = "Düzenlenen Şablon Grubu {1}";
$l['delete_template_group'] = "Şablon Grubunu Sil";
$l['save_template_group'] = "Şablon Grubunu Kaydet";

$l['templates_the_same'] = "Seçmiş olduğunuz her 2 şablon birbiriyle aynıdır ve karşılaştırma yapılamaz.";
$l['master_updated_ins'] = "Şanlonun eski hali ile yeni halindeki farklar ''Kırmızı'' olarak imlenmiştir.";
$l['master_updated_del'] = "Şanlonun eski hali ile özelleştirilmiş halindeki farklar ''Yeşil'' olarak imlenmiştir.";
$l['template_diff_analysis'] = "Fark Analizi Yapılan Şablon";
$l['search_names_header'] = "\"{1}\" ile ilgili şablon isimleri aranıyor...";

$l['updated_template_welcome1'] = "<strong>[Tam Düzenle]</strong> <- Bu seçenek; Seçmiş olduğunuz şablonu düzenlemnize olanak sağlar.";
$l['updated_template_welcome2'] = "<strong>[Orjinal Haline Çevir]</strong> <- Bu seçenek; Düzenleme ve özelleştirme yapmış olduğunuz şablonu orjinal haline geri çevirmenize olanak sağlar, aynı zamanda bu işlem sonucunda şablon üzerindeki tüm düzenleme ve özelleştirmelerinizide siler.";
$l['updated_template_welcome3'] = "<strong>[Farkları Göster]</strong> <- Bu seçenek; Şablonlarda yapmış olduğunuz değişiklik ve özelliştirmelerin arasındaki farkları analiz edebilir ve şablonun bir önceki hali ile editlenmiş/düzenlenmiş veya son güncellemedeki halinin farklarını tespit edebilir.";

$l['no_global_templates'] = "Şu anda eklenmiş herhangi bir genel şablon bulunumadı.";
$l['no_updated_templates'] = "En son versiyon gücellemenizden bu yana, yenilenen veya güncellenen hiçbir şablon bulunamadı.";

$l['confirm_template_set_deletion'] = "Bu şablon setini silmek istediğinize eminmisiniz?";
$l['confirm_template_group_delete'] = "Bu şablon grubunu silmek istediğinizden emin misiniz?<br />Bu işlem, bu şablon grubundaki alt şablonları kaldırmaz, sadece ''ana şablon grubunu'' siler ve alt şablonlarını ''Headerinclude [Gruplandırılmamış] Şablon Grubuna'' aktarır.";
$l['confirm_template_deletion'] = "Bu şablonu silmek istediğinize eminmisiniz?";
$l['confirm_template_revertion'] = "Bu şablonu orjinal haline çevirmek istediğinize eminmisiniz?";

$l['error_security_problem'] = "Potansiyel bir şablon güvenliği sorunu tespit edildi. Lütfen, son yaptığınız değişiklikleri gözden geçirip sorunu düzeltin veya yardım almak için <b><a href=\"http://destek.mybb.com\" target=\"_blank\" title=\"MyBB Resmi Destek Forumu\">MyBB Resmi Destek Forumu</a> ziyaret ediniz.";
$l['error_missing_input'] = "Lütfen bu şablonu düzenlemek için gerekli girşi yaptığınıza emin olunuz. (tid ve sid)";
$l['error_already_exists'] = "Bu şablon başlığı zaten kullanılıyor. Lütfen farklı bir şablon başlığı belirtiniz.";
$l['error_invalid_template'] = "Lütfen geçerli bir şablon seçiniz.";
$l['error_missing_set_title'] = "Lütfen şablon seti için bir başlık giriniz.";
$l['error_invalid_input'] = "Lütfen belirtmiş olduğunuz şablon setinin ID'sının doğru olup olmadığından emin olunuz.";
$l['error_invalid_set'] = "Lütfen geçerli bir şablon seti giriniz.";
$l['error_invalid_template_set'] = "Geçersiz bir şablon seti seçtiniz.";
$l['error_themes_attached_template_set'] = "Bu şablon seti silinemiyor. Çünkü bu şablon setini kullanan tema-(lar) mevcut.";
$l['error_missing_group_prefix'] = "Lütfen, Şablon Grubu için Bir (Ön Ek) Giriniz.";
$l['error_missing_group_title'] = "Lütfen, Şablon Grubu için Bir (Başlık) Giriniz.";
$l['error_duplicate_group_prefix'] = "Girilen (Ön Ek) Başka Bir Şablon Grubu Tarafından Kullanılıyor. Lütfen, Farklı Bir (Ön Ek) Giriniz.";
$l['error_missing_template_group'] = "Şablon Grubu Bulunamadı.";
$l['error_default_template_group'] = "Varsayılan Şablon Grubunu Düzenleyemez ve Kaldıramazsınız.";

$l['success_template_saved'] = "Şablon başarılı olarak kaydedildi.";
$l['success_template_deleted'] = "Şablon başarılı olarak silindi.";
$l['success_template_reverted'] = "Şablon başarılı olarak orjinal haline çevirildi.";
$l['success_template_set_saved'] = "Şablon seti başarılı olarak kaydedildi.";
$l['success_template_set_deleted'] = "Şablon seti başarılı olarak silindi.";
$l['success_template_group_saved'] = "Seçilen şablon grubu başarılı olarak kaydedildi.";
$l['success_template_group_deleted'] = "Seçilen şablon grubu başarılı olarak silindi.";
