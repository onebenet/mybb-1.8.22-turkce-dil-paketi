﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['configuration'] = "Forum Ayarları";

$l['bbsettings'] = "<img src=\"../images/admincp/arac.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Forum Ayarları";
$l['banning'] = "<img src=\"../images/admincp/ban.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Üye Yasaklama";
$l['custom_profile_fields'] = "<img src=\"../images/admincp/profil.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Özel Profil Yönetimi";
$l['smilies'] = "<img src=\"../images/admincp/ifade.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> İfadeler";
$l['word_filters'] = "<img src=\"../images/admincp/filtre.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Kelime Filtreleme";
$l['mycode'] = "<img src=\"../images/admincp/mykod.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Mykod Yönetimi";
$l['languages'] = "<img src=\"../images/admincp/dunya.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Dil Yönetimi";
$l['post_icons'] = "<img src=\"../images/admincp/sembol.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Başlık Sembolleri";
$l['help_documents'] = "<img src=\"../images/admincp/yardim.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Yardım Belgeleri";
$l['plugins'] = "<img src=\"../images/admincp/eklenti.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Plugin Yönetimi";
$l['attachment_types'] = "<img src=\"../images/admincp/ek-dosya.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Ek Dosya Türleri";
$l['moderator_tools'] = "<img src=\"../images/admincp/mod-a.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"Eklentiler\" border=\"0\"> Moderatör Araçları";
$l['spiders_bots'] = "<img src=\"../images/admincp/orumcek.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Örümcek / Botlar";
$l['calendars'] = "<img src=\"../images/admincp/takvim.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Ajanda Yönetimi";
$l['warning_system'] = "<img src=\"../images/admincp/uyari-s.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Uyarı Sistemi";
$l['thread_prefixes'] = "<img src=\"../images/admincp/onek.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Konu Ön Ekleri";
$l['security_questions'] = "<img src=\"../images/admincp/g-soru.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Güvenlik Soruları";
$l['report_reasons'] = "<img src=\"../images/admincp/raporlar.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Rapor Sebepleri";

$l['can_manage_settings'] = "Forum Ayarlarını Yönetebilir Mi?";
$l['can_manage_banned_accounts'] = "Üye Yasaklamayı Yönetebilir Mi?";
$l['can_manage_custom_profile_fields'] = "Özel Profil Alanlarını Yönetebilir Mi?";
$l['can_manage_smilies'] = "İfadeleri Yönetebilir Mi?";
$l['can_manage_bad_words'] = "Kelime Filtrelerini Yönetebilir Mi?";
$l['can_manage_custom_mycode'] = "Mykodları Yönetebilir Mi?";
$l['can_manage_language_packs'] = "Dil Paketlerini Yönetebilir Mi?";
$l['can_manage_post_icons'] = "Başlık Sembollerini Yönetebilir Mi?";
$l['can_manage_help_documents'] = "Yardım Belgelerini Yönetebilir Mi?";
$l['can_manage_plugins'] = "Eklentileri Yönetebilir Mi?";
$l['can_manage_attachment_types'] = "Ek Dosya Türlerini Yönetebilir Mi?";
$l['can_manage_spiders_bots'] = "Örümcek/Botları Yönetebilir Mi?";
$l['can_manage_calendars'] = "Takvim/Ajandayı Yönetebilir Mi?";
$l['can_manage_warning_system'] = "Uyarı Sistemini Yönetebilir Mi?";
$l['can_manage_mod_tools'] = "Moderatör Araçlarını Yönetebilir Mi?";
$l['can_manage_thread_prefixes'] = "Konu Ön Eklerini Yönetebilir Mi?";
$l['can_manage_security_questions'] = "Güvenlik Sorularını Yönetebilir Mi?";
$l['can_manage_report_reasons'] = "Rapor Kayıtlarını Yönetebilir Mi?";
