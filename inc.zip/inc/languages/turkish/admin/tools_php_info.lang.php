﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['php_info'] = "PHP Bilgileri";
$l['browser_no_iframe_support'] = "Tarayıcınız iframeleri desteklemiyor. Lütfen, farklı bir tarayıcı ile deneyiniz.";

