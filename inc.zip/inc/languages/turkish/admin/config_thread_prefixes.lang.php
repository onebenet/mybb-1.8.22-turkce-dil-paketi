﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['thread_prefixes'] = "Konu Ön Ekleri";
$l['thread_prefixes_desc'] = "Bu kısımdan, forumunudaki konuların başlıklarında kullanılabilecek bilgi, (ipucu), amaçlı konu ön eki ekleyebilir yada mevcut olanları düzenleyebilirsiniz.<br />Ayrıca Konu ön ekleri sayesinde forum içindeki konuları kolay bir şekilde filtreleme yapabilirsiniz.";

$l['add_new_thread_prefix'] = "Yeni Ön Ek Ekle";
$l['add_new_thread_prefix_desc'] = "Bu kısımdan, forumunudaki konuların başlıklarında kullanılabilecek bilgi, (ipucu), amaçlı yeni bir konu ön eki ekleyebilirsiniz.";

$l['edit_prefix'] = "Ön Eki Düzenle";
$l['edit_prefix_desc'] = "Bu kısımdan, seçmiş olduğunuz konu ön ekini düzenleyebilir yada daha önce ayarlamış olduğunuz seçeneklerini değiştirebilirsiniz.";
$l['edit_thread_prefix'] = "Ön Eki Düzenle";
$l['delete_thread_prefix'] = "Ön Eki Sil";

$l['prefix_options'] = "Ön Ek Seçenekleri";
$l['save_thread_prefix'] = "Ön Eki Kaydet";

$l['prefix'] = "Mevcut Konu Ön Ekleri";
$l['prefix_desc'] = "Konu açarken başlık kısmının hemen yanındaki, (Ön Ek) seçeneklerinde görüntülenmesini istediğiniz metni yazınız.";
$l['display_style'] = "Ön Ek Gösterim Stili";
$l['display_style_desc'] = "Bu kısımdan, konu ön eki için görüntülenecek stili belirtiniz. <b>HTML</b> kod veya düz metin kullanabilirsiniz.";
$l['available_in_forums'] = "Gösterilecek Forumlar";
$l['available_to_groups'] = "İzin Verilen Gruplar";

$l['no_thread_prefixes'] = "Şu anda kullanılabilecek herhangi bir konu ön eki mevcut değil.";

$l['confirm_thread_prefix_deletion'] = "Bu Konu Ön ekini Silmek İstediğinize Emin Misiniz? Not: Silmeye çalıştığınız Bu Konu ön eki, eğer forumlarda kullanıyor ise, sildikten sonra moderatör araçlarını çalıştırmayı unutmayınız.";

$l['success_thread_prefix_created'] = "Konu Ön eki Başarılı Olarak Oluşturuldu.";
$l['success_thread_prefix_updated'] = "Konu Ön eki Başarılı Olarak Güncellendi.";
$l['success_thread_prefix_deleted'] = "Konu Ön eki Başarılı Olarak Silindi. Lütfen, Bu konu önekini sildikten sonra, eğer forumlarda kullanıyor ise moderatör araçlarını güncellemeyi unutmayınız.";

$l['error_missing_prefix'] = "Lütfen, eklemek için bir konu ön eki metni giriniz.";
$l['error_missing_display_style'] = "Lütfen, konu ön eki için bir görüntü stili giriniz.";
$l['error_no_forums_selected'] = "Lütfen, Bu konu ön eki için kullanılmasını istediğiniz Forum-(ları) seçiniz.";
$l['error_no_groups_selected'] = "Lütfen, Bu konu ön eki için kullanmalarına izin verdiğiniz kullanıcı Grup-(ları) seçiniz.";
$l['error_invalid_prefix'] = "Belirtmiş olduğunuz konu ön eki bulunamadı veya silinmiş olabilir.";

