﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['themes'] = "Temalar & Stiller";
$l['themes_desc'] = "Bu kısımdan, forumunuzda yüklü mevcut tüm temaları yönetebilirsiniz.";

$l['create_new_theme'] = "Tema Oluştur";
$l['create_new_theme_desc'] = "Bu kısımda, varsayılan tema üzerinden yeni bir tema oluşturabilirsiniz. <strong>Şablonlar, stiller ve diğer ayarlar, ana temadan kopyalanır.</strong>";

$l['import_a_theme'] = "Tema Yükle";
$l['import_a_theme_desc'] = "Bu kısımda, forumunuz için bilgisayarınızdan veya URL adresi seçeneklerinden birini kullanarak, yeni bir tema yükleyebilirsiniz.";

$l['edit_stylesheets'] = "CSS Düzenleme";
$l['edit_stylesheets_desc'] = "Bu kısımda, Kolay bir şekilde temanın stillerini değiştirbilirsiniz. Css stil değişikleri ile, tema renklerini, yazı tipini, grafikleri vb. bir çok özelliştirmeyi sağlayabilirsiniz.<br />Bu temaya ait CSS Stilleri aşağıda listelenmiştir.";

$l['add_stylesheet'] = "CSS Oluştur";
$l['add_stylesheet_desc'] = "Bu kısımdan, seçmiş olduğunuz Tema için yeni bir CSS stili oluşturabilirsiniz. Bu stil sayesinde temanıza farklı özellik ve görünümler katabilirsiniz.";

$l['browse_themes'] = "Tema Galerisi";
$l['browse_themes_desc'] = "Bu kısımdan, aşağıda listelenmiş olan MyBB'nin son sürümü ile uyumlu temaları ön izleme yapabilir ve indirebilirsiniz.";

$l['browse_all_themes'] = "Tema Galerisine Git";

$l['export_theme'] = "Temayı İndir";
$l['export_theme_desc'] = "Bu kısımda, seçmiş olduğunuz temayı, şablon ve stilleri ile birlikte kolay bir şekilde indirebilir, başkaları ile paylaşabilir ve diğer forumlarınıza indirmiş olduğunuz, <strong>.XML</strong> dosyasını import edip, grafiklerini <strong>./images</strong> klasöründen çekerek, yükleyebilirsiniz.";

$l['duplicate_theme'] = "Temayı Çoğalt";
$l['duplicate_theme_desc'] = "Bu kısımdan, temaları çoğaltabilir farklı versiyonlarını üretebilirsiniz.";

$l['colors_manage'] = "Renk Yönetimi";
$l['colors_attached_to'] = "Renk Ayarları";
$l['colors_setting'] = "Temel Renkler:";
$l['colors_setting_desc'] = "Bu tema için temel olarak kullanılacak rengi seçiniz.";
$l['colors_no_color_setting'] = "Şu anda hiçbir renk mevcut değil. Bu özelliği kullanabilmek için aşağıdaki kısımdan bir renk listesi oluşturabilirsiniz.";
$l['colors_add'] = "Renkleri Yönet:";
$l['colors_add_desc'] = "Bu tema için kullanılabilir renk listesi.<br />Bu kısımda, listeye daha fazla renk eklemek için eşleştirilmiş bir anahtar ve madde giriniz.<br /><strong>Örnek:</strong> (anahtar=madde), Örneğin, <em>onebe=ONEBE</em> , <em>mavi=Mavi</em> . Burada dikkat edilmesi gereken nokta, her anahtar ve madde arasında, <strong>=</strong> karakterinin kullanılmasıdır.";
$l['colors_please_select'] = "Hiçbiri";
$l['colors_add_edit_desc'] = "Bu stile eklenmesi için bir renk seçiniz. Birden fazla renk seçebilirsiniz.";
$l['colors_specific_color'] = "Özel Renkler";

$l['include_custom_only'] = "Sadece Özelleştirilmiş CSS Stillerini Dahil Et?";
$l['include_custom_only_desc'] = "Bu kısımdan sadece özelleştirme yapmış olduğunuz CSS stillerini dahil etmek istiyorsanız <strong>''Evet''</strong> seçeneğini seçiniz.<br />Temaya ait tüm CSS stillerinin dahil olması için <strong>''Hayır''</strong> seçeneğini seçiniz.";
$l['include_templates'] = "Tüm Şablon ve Şablon Gruplarını Dahil Et?";
$l['include_templates_desc'] = "Temaya ait tüm şablon ve şablon gruplarını dahil etmek için <strong>''Evet''</strong> seçeneğini seçiniz.<br />Sadece özeleştirme yaptığınız şablon ve şablon gruplarını içermesi için <strong>''Hayır''</strong> seçeneğini seçiniz.";

$l['edit_stylesheet_simple_mode'] = "Basit Düzenleme";
$l['edit_stylesheet_simple_mode_desc'] = "Bu kısımda, temanızın stillerini, basit veya <strong>gelişmiş düzenleme</strong> seçenekleri ile kolay bir şekilde özelleştirebilirsiniz.";
$l['edit_stylesheet_advanced_mode'] = "Gelişmiş Düzenleme";
$l['edit_stylesheet_advanced_mode_desc'] = "Bu kısımda, temanın stillerini düz bir metin görünümü gibi kolay bir şekilde düzenleme yapabilirsiniz. CSS kodları aşağıdaki metin kutusu içinde yer almaktadır.";

$l['theme'] = "Tema Listesi";
$l['num_users'] = "@ Kullanıcı";
$l['edit_theme'] = "Temayı Düzenle";
$l['delete_theme'] = "Temayı Sil";
$l['set_as_default'] = "Varsayılan Yap";
$l['default_theme'] = "Varsayılan Tema";
$l['force_on_users'] = "Kullanıcılara Zorla";
$l['delete_revert'] = "Sil \ Orjinale Dönüştür";

$l['local_file'] = "Bilgisayarından Yükle";
$l['url'] = "URL Adresi ile Yükle";
$l['import_from'] = "Yükleme Bilgisi:";
$l['import_from_desc'] = "Bu kısımda, forumunuza yüklemek istediğiniz temanın <strong>.xml</strong> dosyasını bilgisayarınızdan veya URL adresi ile kolay bir şekilde yükleyebilirsiniz.";
$l['parent_theme'] = "Ana Tema Seçimi:";
$l['parent_theme_desc'] = "Bu kısımda, alt teması olmasını istediğiniz, ana temayı seçiniz. Genelikle bu ayar <strong>MyBB Master Style</strong> olarak seçilir.";
$l['new_name'] = "Tema İsmi:";
$l['new_name_desc'] = "Bu kısımda, yüklemek istediğiniz tema için yeni bir isim kullanabilirsiniz. <strong>Örnek</strong> onebe.net Teması gibi. <img src=\"../images/smilies/tongue.gif\" alt=\"\" width=\"18\" height=\"18\" style=\"vertical-align: middle;\">";
$l['advanced_options'] = "Gelişmiş Yükleme Seçenekleri:";
$l['ignore_version_compatibility'] = "Versiyon Uyumluluğunu Yoksay";
$l['ignore_version_compat_desc'] = "Bu seçenek, yüklemek istediğiniz temanın farklı MyBB sürümlerine göre yapıldığını göz ardı edecektir.";
$l['import_stylesheets'] = "Stil Sayfaları Yüklensin mi?";
$l['import_stylesheets_desc'] = "Bu seçenek, yüklemek istediğiniz temanın tüm stil sayfalarının yüklenmesine olanak sağlar.";
$l['import_templates'] = "Şablonlar Yüklensin mi?";
$l['import_templates_desc'] = "Bu seçenek, yüklemek istediğiniz temanın tüm şablonlarının yüklenmesine olanak sağlar.<br /><div style=\"border-bottom: 1px dotted rgb(102, 102, 102); margin: 5px 0pt;\"></div><font color=\"#a21313\"><span style=\"font-size: large;\" color=\"#a21313\">Tema Nasıl Yüklenir?</span></font><br /><strong>Yeni bir tema yüklemek için:</strong> yüklemek istediğiniz tema grafikleri klasörünü ./images klasörünün içine yüklüyorsunuz. Burada dikkat edilmesi gereken nokta, temayı indirdiğiniz konuda eğer tema grafiklerinin klasörü ./images içine yüklenecek ise ./images içine yüklüyorsunuz, ayrı bir dizine ya da ./images klasörünün dışına yüklenecek ise bu durumda ./images klasörünün olduğunu dizine yüklüyorsunuz. Tema grafiklerini yükledikten sonra, indirmiş olduğunuz tema klasörünün içindeki <strong>.xml</strong> uzantılı dosyayı üsteki gözat butonu aracı ile bilgisayarımızdaki yolunu belirtiyorsunuz. Daha sonra <strong>Ana Tema Seçimi</strong>ne dokunmadan bir aşağıdaki seçeneğe temanız için yeni bir isim yazınız. Son olarak <strong>Gelişmiş Seçenekler</strong>'den eğer temanızın versiyonu eski veya ne olduğu hakkında bilginiz yok ise, <strong>Versiyon Uyumluluğunu Yoksay</strong> seçeneğini işaretleyerek, en aşağıdaki <strong>Temayı Yükle</strong> butonuna basıyorsunuz ve işlem tamamdır.";
$l['import_theme'] = "Temayı Yükle";

$l['new_name_duplicate_desc'] = "Temayı çoğaltabilmek için yeni bir isim giriniz.";
$l['duplicate_stylesheets'] = "Stilleri Çoğalt";
$l['duplicate_stylesheets_desc'] = "Bu tema özel ''CSS Stil Kalıpları'' içeriyorsa onlarda dahil edilsin mi?";
$l['duplicate_templates'] = "Şablonları Çoğalt";
$l['duplicate_templates_desc'] = "Bu tema özel ''Şablon'' ve ''Şablon Grupları'' içeriyorsa onlarda dahil edilsin mi?";

$l['create_a_theme'] = "Yeni Tema Oluşturma";
$l['name'] = "Tema İsmi:";
$l['name_desc'] = "Bu kısımda, aşağıdaki metin kutusuna oluşturmak istediğiniz tema için bir isim giriniz.";
$l['display_order'] = "Sıralama";

$l['edit_theme_properties'] = "Tema Özelliklerini Düzenleme";
$l['name_desc_edit'] = "Bu kısımda, aşağıdaki metin kutusuna mevcut yada oluşturmak istediğiniz tema için bir isim giriniz.";
$l['allowed_user_groups'] = "İzin Verilen Kullanıcı Grupları:";
$l['allowed_user_groups_desc'] = "Bu temayı kullanmalarına izin verdiğiniz kullanıcı gruplarını seçiniz. Çoklu seçim için  <strong>Tüm Kullanıcı Grupları</strong>nı seçiniz veya <strong>CTRL</strong> tuşunu kullanınız.";
$l['all_user_groups'] = "Tüm Kullanıcı Grupları";
$l['template_set'] = "Kullanılacak Şablon Seti:";
$l['template_set_desc'] = "Bu kısımda, bu tema için tema yükleme kısmındaki yüklemiş olduğunuz xml dosyasının şablon setini seçiyorsunuz. Farklı şablon seti seçtiğinizde temanızın bozulmasına neden olabilir.";
$l['editor_theme'] = "Konu Açma Editörünün Stili:";
$l['editor_theme_desc'] = "Bu kısımda, konu ve hızlı cevap editörünün stilini seçiniz. Editör stilini özelleştirmek için  <strong>Ftp aracılığı ile  ./jscripts/editor_themes</strong> klasöründen gerekli düzenlemeleri yapabilirsiniz.";
$l['img_directory'] = "Tema Klasörünün Yolu:";
$l['img_directory_desc'] = "Bu kısımda, Bu tema için kullanılacak olan resim klasörünün yolu giriniz. Bu resim klasörü şablonlarınızda kullanılan grafik yolunu belirlemek içindir.<br /><strong>Örnek:</strong> ./images/onebe-v1 gibi.";
$l['logo'] = "Forum Logosunun Yolu:";
$l['logo_desc'] = "Bu kısımda, forumunuz için kullanmak istediğiniz log'nun yolunu giriniz. Bu logo tüm sayfaların en üstünde görüntülenir.";
$l['table_spacing'] = "Tablo Aralığı:";
$l['table_spacing_desc'] = "Bu seçenek, tablo hücrelerinin arasındaki boşlukları, piksel cinsinden genişliğini ayarlamanıza olanak sağlar. Bu özellik HTML-in <em>table</em> tagının, <em><strong>cellspacing</strong></em> özniteliği olarak kullanılır.";
$l['inner_border'] = "Tablo İçi Sınır Genişliği:";
$l['inner_border_desc'] = "Bu seçenek, her tablo hücrelerinin arasındaki boşluk miktarını ayarlamanıza olanak sağlar. Bu özellik HTML-in <em>table</em> tagının, <em><strong>cellspacing</strong></em> özniteliği olarak kullanılır.";
$l['save_theme_properties'] = "Tema Özelliklerini Kaydet/Güncelle";
$l['save_stylesheet_order'] = "Stil Sıralamasını Kaydet/Güncelle";

$l['background'] = "Arkaplan Resmi";
$l['extra_css_atribs'] = "İlave CSS Nitelikleri";
$l['color'] = "Arkaplan Rengi";
$l['width'] = "Forum Genişliği";
$l['text_decoration'] = "Metin Dekorasyonu";
$l['font_family'] = "Font Ailesi";
$l['font_size'] = "Yazı Boyutu";
$l['font_style'] = "Yazı Tipi";
$l['font_weight'] = "Yazı Genişliği";

$l['stylesheets'] = "CSS Stilleri Listesi";
$l['inherited_from'] = "Ana Tema:";
$l['attached_to'] = "İlişkilendirilen:";
$l['attached_to_nothing'] = "İlişkilendirilmiş birşey yok";
$l['attached_to_desc'] = "Bu kısımda, genel olarak kullanılması için bir stil sayfası veya özel dosyalar oluşturabilirsiniz. Eğer özel dosyalar oluşturacaksanız, her dosya için özel hareketlerde oluşturabilirsiniz.";
$l['actions'] = "Hareket";
$l['of'] = "";
$l['attached_to_all_pages'] = "İlişkilendirilen: Tüm Sayfalarda Kullanılan";
$l['properties'] = "Stil Özellikleri";
$l['edit_style'] = "Stili Düzenle";
$l['stylesheets_in'] = "Stillerin Kullanıldığı Tema:";
$l['stylesheet_properties'] = "Stil Sayfası Özellikleri";
$l['stylesheet_inherited_default'] = "Bu stil sayfası, şu anda {1} tarafından kullanılmaktadır. Yapacağınız tüm değişikler bu stilin kullanıdığı temayı bozabilir.";
$l['stylesheet_inherited'] = "Bu stil sayfası, şu anda {1} tarafından kullanılmaktadır. Yapacağınız tüm değişikler bu stilin kullanıdığı temayı bozabilir. Düzenleme yapmak için bu {1} temayı kullanın.";
$l['globally'] = "Genel Stil";
$l['specific_files'] = "Özel Dosyalar";
$l['specific_actions'] = "Özel Hareketler";
$l['specific_actions_desc'] = "Eklemek istediğiniz özel hareketleri virgül ile ayırınız.";
$l['file'] = "Dosya Yolu";
$l['add_another'] = "Bir Tane Daha Ekle";
$l['edit_stylesheet_properties_for'] = "Özellikleri Düzenlenen Stil Sayfası:";
$l['file_name'] = "Stil Adı";
$l['file_name_desc'] = "Oluşturmak istediğiniz stil sayfasının adını giriniz. Stil sayfası isimlerinde genellikle, <strong>[.css]</strong> uzantısı kullanılır.<br /><strong>Örnek:</strong>&nbsp;mybb.css gibi olmalıdır.";
$l['save_stylesheet_properties'] = "Stil Sayfası Özelliklerini Kaydet";
$l['saved'] = "Kaydedildi";
$l['editing'] = "Düzenleniyor";
$l['selector'] = "Seçici";
$l['save_changes'] = "Değişiklikleri Kaydet";
$l['save_changes_and_close'] = "Değişiklikleri Kaydet ve Kapat";
$l['save_changes_js'] = "Yapmış olduğunuz değişiklikleri kaydetmek istediğinizden emin misiniz?";
$l['delete_confirm_js'] = "Bunu Silmek istediğinize emin misiniz?";
$l['import_stylesheet_from'] = "Bu temadaki başka bir stil sayfasından yükle";
$l['write_own'] = "Kendi içeriğimi yazmak istiyorum";
$l['save_stylesheet'] = "Stil Sayfasını Kaydet";
$l['add_stylesheet_to'] = "Stil Sayfasının Ekleneceği Tema:";

$l['full_stylesheet_for'] = "Genel Stil Sayfası:";

$l['recommended_themes_for_mybb'] = "MyBB {1} Versiyonu ile Uyumlu Tavsiye Edilen Temalar";
$l['browse_results_for_mybb'] = "MyBB {1} Versiyonu ile Uyumlu Temaların Arama Sonuçları";
$l['search_for_themes'] = "Tema Ara..";
$l['search'] = "Ara/Bul";
$l['download'] = "İndir";
$l['created_by'] = "<strong>Tema Yapımcısı:</strong>";

$l['error_invalid_stylesheet'] = "Geçersiz bir stil sayfası seçtiniz.";
$l['error_invalid_theme'] = "Geçersiz bir tema seçtiniz.";
$l['error_missing_name'] = "Lütfen bu tema için bir isim giriniz.";
$l['error_missing_url'] = "Lütfen yüklemek istediğiniz tema için geçerli bir URL adresi girin.";
$l['error_theme_already_exists'] = "Aynı isimde zaten başka bir tema var. Lütfen, bu tema için farklı bir isim girin.";
$l['error_theme_security_problem'] = "Güvenlik sorunu oluşturabilecek yüklü bir tema tespit edildi. Lütfen, son yüklediğiniz tema-ları kontrol edip güvenlik sorununu düzeltin veya yadım almak için <strong><a href=\"http://destek.mybb.com\" target=\"_blank\" title=\"MyBB Resmi Destek Forumu\">MyBB Resmi Destek Forumu</a> ziyaret ediniz.";

$l['error_local_file'] = "Dosya yüklenemedi. Lütfen Bilgisayarınızdan yüklemek istediğiniz dosyanın mevcut olup olmadığını kontrol ediniz.";
$l['error_uploadfailed'] = "Yükleme işlemi Başarısız sonuçlandı. Lütfen tekrar yüklemeyi deneyiniz.";
$l['error_uploadfailed_detail'] = "Hata Ayrıntıları: ";
$l['error_uploadfailed_php1'] = "PHP Döngüsü: Yüklemeye çalıştığınız dosya, php.ini-ye bağlı Maksimum dosya yükleme sınırı aştı . Lütfen, bu hata için forum yönecisi ile iletişim kurunuz.";
$l['error_uploadfailed_php2'] = "Yüklemeye çalıştığınız dosya, belirtilen maksimum dosya boyutu aştı.";
$l['error_uploadfailed_php3'] = "Yüklemeye çalıştığınız dosyanın sadece bir kısmı yüklenebildi.";
$l['error_uploadfailed_php4'] = "Dosya Yüklenemedi!";
$l['error_uploadfailed_php6'] = "PHP Döngüsü: Geçici klasör bulunamadı. Lütfen, bu hata için forum yönecisi ile iletişim kurun.";
$l['error_uploadfailed_php7'] = "PHP Döngüsü: Dosya yüklenirken bir hata oluştu.  Lütfen, bu hata için forum yönecisi ile iletişim kurun.";
$l['error_uploadfailed_phpx'] = "PHP Döngüsü Hata Kodu: {1}.  Lütfen, bu hata için forum yönecisi ile iletişim kurun.";
$l['error_uploadfailed_lost'] = "Dosya bu sunucuda bulunamadı.";
$l['error_uploadfailed_nocontents'] = "Sistem yüklemek istediğiniz dosyada, tema bulamadı. Lütfen dosyada tema olup olmadığını kontrol ediniz.";
$l['error_invalid_version'] = "Bu tema başka bir MyBB sürümü için kodlanmış. Lütfen, bu hatayı göz ardı etmek için <strong>''Versiyon Uyumluluğunu Yoksay''</strong>ı seçiniz.";
$l['error_missing_stylesheet_name'] = "Lütfen bu stil sayfası için bir isim giriniz.";
$l['error_missing_stylesheet_extension'] = "Bu stil örnek, {1}<em>.css</em> uzantısı gibi olmalıdır.";
$l['error_invalid_parent_theme'] = "Seçmiş olduğunuz ana tema mevcut değil. Lütfen geçerli bir ana tema seçiniz.";
$l['error_invalid_templateset'] = "Seçmiş olduğunuz şablon seti mevcut değil. Lütfen geçerli bir şablon seti seçiniz.";
$l['error_invalid_editortheme'] = "Seçmiş olduğunuz editör stili mevcut. Lütfen geçerli bir editör stili seçiniz.";
$l['error_inheriting_stylesheets'] = "Bu temayı silemezsiniz. Çünkü hala bu temaya ait, başka temalarda kullanılan stil sayfaları var.";
$l['error_cannot_parse'] = "Sistem bu stil sayfasını basit düzenleme modunda çözümleyemedi. Bu stil sayfasını düzenlemek için gelişmiş düzenleme modunu kullanmalısınız.";
$l['error_communication_problem'] = "MyBB.Com sunucusundan temalar yüklenirken bir sorun oluştu. Lütfen daha sonra tekrar deneyiniz. :/";
$l['error_no_results_found'] = "Arama teriminize uygun herhangi bir sonuç bulunamadı.";
$l['error_no_color_picked'] = "Bu stile eklenmesi için herhangi bir renk belirtmediniz.";
$l['error_no_display_order'] = "Stiller sıralandırılırken bir hata oluştu. Lütfen, sayfayı yenileyip tekrar deneyiniz.";

$l['success_duplicated_theme'] = "Seçilen tema başarılı olarak kopyalanıp çoğaltılmıştır. :)";
$l['success_imported_theme'] = "Seçilen tema başarılı olarak yüklendi.";
$l['success_theme_created'] = "Tema başarılı olarak oluşturuldu.";
$l['success_theme_deleted'] = "Seçilen tema başarılı olarak silindi.";
$l['success_stylesheet_properties_updated'] = "Seçilen stil sayfası için düzenlemiş olduğunuz özellikle başarılı olarak güncellendi.";
$l['success_stylesheet_updated'] = "Seçilen stil sayfası başarılı olarak güncellendi.";
$l['success_stylesheet_deleted'] = "Seçilen stil sayfası başarılı olarak silindi \ iptal edildi.";
$l['success_theme_set_default'] = "Seçilen tema başarıyla varsayılan tema olarak ayarlandı.";
$l['success_theme_forced'] = "Tüm kullanıcılara, seçmiş olduğunuz temayı kullanmaları için başarılı olarak zorunluluk sağlandı.";
$l['success_theme_properties_updated'] = "Seçmiş olduğunuz temanın özellikleri başarılı olarak güncellendi.";
$l['success_stylesheet_added'] = "Bu tema için stil sayfası başarılı olarak oluşturuldu.";
$l['success_stylesheet_order_updated'] = "Stil sıralaması başarılı olarak güncellendi.";

$l['confirm_theme_deletion'] = "Bu temayı silmek istediğinize emin misiniz?";
$l['confirm_stylesheet_deletion'] = "Bu stil sayfasının silinmesini \ iptal edilmesini istediğinizden emin misiniz?";
$l['confirm_theme_forced'] = "Tüm kullanıcıların bu temayı zorunlu olarak kullanmalarını istediğinizden emin misiniz?";

$l['theme_info_fetch_error'] = 'Stil bilgileri alınırken bir hata oluştu.';
$l['theme_info_save_error'] = 'Stil bilgileri kaydedilirken bir hata oluştu.';

$l['saving'] = 'Kaydediliyor...';

