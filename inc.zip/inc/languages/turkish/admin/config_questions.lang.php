﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi 
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['security_questions'] = "Güvenlik Soruları";
$l['security_questions_desc'] = "Bu kısımdan, üye kayıt sayfasında gösterilecek olan güvenlik sorularını yönetebilirsiniz.";
$l['add_new_question'] = "Yeni Soru Ekle";
$l['add_new_question_desc'] = "Bu kısımdan, kayıt sayfasında gösterilecek olan yeni güvenlik sorularını ve cevaplarını ekleyebilirsiniz.";
$l['edit_question'] = "Soruyu Düzenle";
$l['edit_question_desc'] = "Bu kısımdan, seçmiş olduğunuz güvenlik sorusunu düzenleyebilirsiniz.";

$l['options'] = "Seçenekler";
$l['correct'] = "Doğru";
$l['incorrect'] = "Yanlış";
$l['disable_question'] = "Soruyu Pasifleştir";
$l['enable_question'] = "Soruyu Aktifleştir";
$l['delete_question'] = "Soruyu Sil";
$l['no_security_questions'] = "Şu anda foruma ekli hiçbir güvenlik sorusu mevcut değil.";

$l['question'] = "Soru";
$l['question_desc'] = "Kayıt sayfasında gösterilecek olan, yanıtlanmasını istediğiniz bir soru giriniz. (Bu kısımda, [HTML] kod kullanabilirsiniz).";
$l['answers'] = "Cevap";
$l['answers_desc'] = "Yukarıdaki soru için bir yanıt/cevap giriniz. Birden fazla cevabı ayrı satır olarak, (alt alta) giriniz.";
$l['active'] = "Aktif Edilsin Mi?";
$l['save_question'] = "Soruyu Kaydet";

$l['error_invalid_question'] = "Geçersiz bir soru seçtiniz.";
$l['error_missing_question'] = "Bu soru için hiçbir soru girmediniz.";
$l['error_missing_answer'] = "Bu soru için herhangi bir cevap girmediniz.";

$l['success_question_created'] = "Soru Başarılı Olarak Oluşturuldu.";
$l['success_question_updated'] = "Soru Başarılı Olarak Güncellendin.";
$l['success_question_disabled'] = "Soru Başarılı Olarak Devre Dışı Bırakıldı.";
$l['success_question_enabled'] = "Soru Başarılı Olarak Aktif Edildi.";
$l['success_question_deleted'] = "Soru Başarılı Olarak Silindi.";

$l['confirm_question_deletion'] = "Bu soruyu silmek istediğinizden emin misiniz?";

