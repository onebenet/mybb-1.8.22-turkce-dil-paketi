﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['warning_system'] = "Uyarı Sistemi";
$l['warning_types'] = "Uyarı Türleri";
$l['warning_types_desc'] = "Bı kısımdan, kullanıcılar için listelenen mevcut uyarı türlerini yönetebilirsiniz.";
$l['add_warning_type'] = "Yeni Uyarı Türü Ekle";
$l['add_warning_type_desc'] = "Bu kısımdan, forumunuzdaki kullanıcılara uyarı puanı vermek için yeni bir uyarı türü oluşturabilirsiniz. Oluşturacağınız uyarı türündeki puan ve uyarı bitiş tarihinide yine bu kısımdan ayarlayabilirsiniz.";
$l['edit_warning_type'] = "Uyarı Türünü Düzenle";
$l['edit_warning_type_desc'] = "Bu kısımdan, seçmiş olduğunuz uyarı türünü değiştirebilirsiniz. Düzenlemek istediğiniz uyarı türündeki puan ve uyarı bitiş tarihinide yine bu kısımdan ayarlayabilirsiniz.";
$l['warning_levels'] = "Uyarı Seviyeleri";
$l['warning_levels_desc'] = "Uyarı seviyeleri, bir kullanıcının maksimum uyarı yüzdesine ulaştığını tanımlar. Bu uyarılar belirlemiş olduğunuz seçeneklere göre kullanıcıları banlayabilir, foruma yolladıkları konu ve yorumlarını engelleme ve  moderasyona alabilir.";
$l['add_warning_level'] = "Yeni Uyarı Seviyesi Ekle";
$l['add_warning_level_desc'] = "Bu Kısımdan, yeni bir uyarı seviyesi ekleyebilirsiniz. uyarı seviyesi kullanıcıların maksimum yüzde oranına ulaştıklarında uygulanacaktır.";
$l['edit_warning_level'] = "Uyarı Seviyesi Düzenle";
$l['edit_warning_level_desc'] = "Bu Kısımdan, seçmiş olduğunuz uyarı oranını düzenleyebilir, maksimum yüzde ayarları ve seçeneklerini değiştirebilirsiniz.";

$l['percentage'] = "Seviye";
$l['action_to_take'] = "Uygulanacak İşlem";
$l['move_banned_group'] = "{1} {2} {3} grubuna taşı";
$l['move_banned_group_permanent'] = "Kalıcı Olarak ({1}) grubuna taşı";
$l['suspend_posting'] = "{1} {2} Konu ve yorum göndermesini engelle";
$l['suspend_posting_permanent'] = "Kalıcı olarak, Konu ve yorum göndermesi engelle";
$l['moderate_new_posts'] = "{1} {2} konu ve yorumlarını moderasyona al";
$l['moderate_new_posts_permanent'] = "Kalıcı olarak, konu ve yorumlarını moderasyona al";
$l['no_warning_levels'] = "Şu an forumunuzda oluşturulmuş, herhangi bir Uyarı Seviyesi mevcut değil.";

$l['warning_type'] = "Uyarı Türü";
$l['points'] = "Puan";
$l['expires_after'] = "Sona Eriş";
$l['no_warning_types'] = "Şu an forumunuzda oluşturulmuş, herhangi bir uyarı türü mevcut değil.";

$l['warning_points_percentage'] = "Maksimum Uyarı Puanı Seviyesi";
$l['warning_points_percentage_desc'] = "Lütfen uyarı puanı için, 1 ile 100 arası sayısal bir değer giriniz.";
$l['action_to_be_taken'] = "Uygulanacak İşlem";
$l['action_to_be_taken_desc'] = "Kullanıcıların, üsteki belirtmiş olduğunuz uyarı puanı oranına ulaştıklarında, uygulanması gereken işlemi seçiniz.";
$l['ban_user'] = "Kullanıcıyı Yasakla";
$l['banned_group'] = "Yasaklı Kullanıcı Grubu:";
$l['ban_length'] = "Yasak Süresi:";
$l['suspend_posting_privileges'] = "Konu & Yorumlarını Engelle";
$l['suspension_length'] = "Engelleme Süresi:";
$l['moderate_posts'] = "Konu & Yorumlarını Moderasyona Al";
$l['moderation_length'] = "Moderasyon Süresi:";
$l['save_warning_level'] = "Uyarı Seviyesini Kaydet";

$l['title'] = "Başlık";
$l['points_to_add'] = "Eklenecek Uyarı Puanı";
$l['points_to_add_desc'] = "Bir kullanıcıya eklenecek uyarı seviyesi puanıdır.";
$l['warning_expiry'] = "Sona Eriş";
$l['warning_expiry_desc'] = "Bu uyarının sona eriş süresini giriniz.";
$l['save_warning_type'] = "Uyarı Türünü Kaydet";

$l['expiration_hours'] = "Saat";
$l['expiration_days'] = "Gün";
$l['expiration_weeks'] = "Hafta";
$l['expiration_months'] = "Ay";
$l['expiration_never'] = "Süresiz";
$l['expiration_permanent'] = "Süresiz";

$l['error_invalid_warning_level'] = "Belirtmiş olduğunuz uyarı seviyesi bulunamadı.";
$l['error_invalid_warning_percentage'] = "Bu uyarı seviyesi için geçerli bir yüzdelik değeri girmediniz. Yüzdelik değeri 1 ile 100 arasında olmalıdır.";
$l['error_invalid_warning_type'] = "Belirtmiş olduğunuz uyarı türü bulunamadı.";
$l['error_missing_action_type'] = "Lütfen, bu yeni uyarı türü ile atamak için bir uyarı türü seçiniz.";
$l['error_missing_type_title'] = "Bu uyarı türü için bir başlık girmediniz.";
$l['error_missing_type_points'] = "Belirtmiş olduğunuz puan değeri bu uyarı türü için kullanılabilecek geçerli bir değer değil.  0 ila {1} arası bir değer girmelisiniz.";

$l['success_warning_level_created'] = "Uyarı seviyesi başarılı olarak oluşturuldu.";
$l['success_warning_level_updated'] = "Uyarı seviyesi başarılı olarak güncellendi.";
$l['success_warning_level_deleted'] = "Uyarı seviyesi başarılı olarak silindi.";
$l['success_warning_type_created'] = "Uyarı türü başarılı olarak oluşturuldu.";
$l['success_warning_type_updated'] = "Uyarı türü başarılı olarak güncellendi.";
$l['success_warning_type_deleted'] = "Uyarı türü başarılı olarak silindi.";

$l['confirm_warning_level_deletion'] = "Bu uyarı seviyesini silmek istediğinizden emin misiniz?";
$l['confirm_warning_type_deletion'] = "Bu uyarı türünü silmek istediğinizden emin misiniz?";

