<?php
/**
 * MyBB 1.8
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['hello_desc'] = 'Dizin sayfasında mesaj oluşturmanıza ve bunları her gönderiye eklemenize olanak tanıyan örnek bir eklenti.';

$l['setting_group_hello'] = 'Selam Dünya!';
$l['setting_group_hello_desc'] = 'Merhaba Dünya için Ayarlar! Eklenti.';

$l['setting_hello_display1'] = 'Mesaj Dizini Görüntüle';
$l['setting_hello_display1_desc'] = 'İletileri dizinde görüntülemek istemiyorsanız hayır olarak ayarlayın.';

$l['setting_hello_display2'] = 'Mesajı Postbitte Görüntüle';
$l['setting_hello_display2_desc'] = 'Her yazının altındaki mesajları görüntülemek istemiyorsanız hayır olarak ayarlayın.';

$l['hello_uninstall'] = 'Selam Dünya! kaldırma';
$l['hello_uninstall_message'] = 'Veritabanındaki tüm mesajları kaldırmak istiyor musunuz??';