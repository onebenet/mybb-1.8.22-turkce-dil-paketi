﻿<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8.22 Türkçe Dil Paketi
 * Telif Hakkı 2020 ONEBE.NET, Tüm Hakları Saklıdır
 */

$l['nav_register'] = "Kayıt Ol";
$l['nav_activate'] = "Aktifleştir";
$l['nav_resendactivation'] = "Aktivasyon Mailini Yeniden Gönder";
$l['nav_lostpw'] = "Şifremi Unuttum?";
$l['nav_resetpassword'] = "Şifreyi Yenile";
$l['nav_login'] = "Giriş Yap";
$l['nav_emailuser'] = "E-posta Gönder";
$l['nav_profile'] = "{1}, Adlı Kullanıcının Profil Bilgileri";

$l['tpp_option'] = "Sayfa Başına {1} Konuları";
$l['ppp_option'] = "Sayfa Başına {1} Yorumları";
$l['account_activation'] = "Hesap Etkinleştirme";
$l['activate_account'] = "Hesabı Etkinleştir";
$l['activation_code'] = "Aktivasyon Kodu";

$l['email_user'] = "{1} Adlı Kullanıcıya E-posta Gönder";
$l['email_subject'] = "Konu Başlığı:";
$l['email_message'] = "Mesaj İçeriği:";
$l['send_email'] = "Gönder";
$l['error_hideemail'] = "Alıcı E-posta adresini gizlediğinden dolayı, e-postanız gönderilemiyor.";
$l['error_no_email_subject'] = "E-posta için bir konu başlığı girmeniz gerekiyor.";
$l['error_no_email_message'] = "E-posta için bir mesaj içeriği yazmanız gerekiyor.";

$l['login'] = "Giriş Yap";
$l['pw_note'] = "Lütfen Unutmayın, şifreler hasas ve Büyük / küçük harf duyarlıdır.";
$l['lostpw_note'] = "Şifreni mi Unuttun?";
$l['lost_pw'] = "Şifremi Unuttum?";
$l['lost_pw_form'] = "Kayıp Şifreyi Yenile";
$l['email_address'] = "E-Posta Adresiniz:";
$l['request_user_pass'] = "Yeni Şifre İsteğini Gönder";
$l['profile'] = "{1} - Profil Bilgileri";
$l['registration_date'] = "Üyelik Tarihi:";
$l['date_of_birth'] = "Doğum Tarihi:";
$l['birthdayhidden'] = "Gizli";
$l['birthday'] = "Doğum Günü:";
$l['local_time'] = "Şu anki Tarih:";
$l['local_time_format'] = "{1} <strong>Saat:</strong> {2}";
$l['users_forum_info'] = "Forum Bilgileri";
$l['joined'] = "Kayıt Tarihi:";
$l['lastvisit'] = "Son Ziyareti:";
$l['total_posts'] = "Yorumları:";
$l['ppd_percent_total'] = "Günlük ortalama {1} | Toplam yorumların %{2}";
$l['total_threads'] = "Konuları:";
$l['tpd_percent_total'] = "Günlük ortalama {1} | Toplam konuların %{2}";
$l['find_posts'] = "Tüm Yorumlarını Gör";
$l['find_threads'] = "Tüm Konularını Gör";
$l['members_referred'] = "Referansları:";
$l['rating'] = "Oyla:";
$l['users_contact_details'] = "İletişim Bilgileri";
$l['homepage'] = "Web Sitesi:";
$l['pm'] = "Özel Mesaj:";
$l['send_pm'] = "{1} - Özel Mesaj Gönder";
$l['icq_number'] = "ICQ Numarası:";
$l['aim_screenname'] = "AIM Ekran Adı:";
$l['yahoo_id'] = "Yahoo Mail:";
$l['skype_id'] = "Skype ID:";
$l['google_id'] = "Google Talk ID:";
$l['avatar'] = "Avatar:";
$l['warning_level'] = "Uyarı Seviyesi:";
$l['warn'] = "Uyar";
$l['away_note'] = "{1} - Şu anda izinli";
$l['away_reason'] = "<strong>İzin Sebebi:</strong>";
$l['away_since'] = "<strong>İzine Çıkış Tarihi:</strong>";
$l['away_returns'] = "<strong>İzinden Dönüş Tarihi:</strong>";
$l['away_no_reason'] = "Belirtilmemiş";
$l['ban_note'] = "Bu kullanıcı hesabı yasaklanmıştır.";
$l['ban_by'] = "Yasaklayan";
$l['ban_length'] = "Yasak Süresi";
$l['ban_remaining'] = "Kalan";

$l['users_additional_info'] = "{1}, Hakkında Kişisel Bilgiler";
$l['email'] = "E-Posta:";
$l['send_user_email'] = "{1} - E-Posta Gönder";
$l['users_signature'] = "Forum İmzası";
$l['agreement'] = "Üye Kayıt Sözleşmesi";
$l['agreement_1'] = "<b>Bu forumda kabul ettiğiniz koşullar çerçevesinde:</b> kesinlikle cinsellik, yanlış, yanıltıcı, yasadışı örgütlenme, kırıcı, kişisel gizlilik, ''uluslararası'' ve <b>''Türkiye Cumhuriyeti''</b> Yasaları'na aykırı içeriği olan konular açamaz ve yorumlar yazamazsınız. Bunun yanında telif hakkı içeren dosya vb. materyalleri de paylaşamazsınız.";
$l['agreement_2'] = "Pornografik içerik,yasadışı ilaçlar ve ilaç üretim cihazları,kumar ve kumar ile alakalı içerik,silah ve silah mühimmatlarının satışı, bira veya sert alkollü içecek tanıtım yada satışı,tütün yada tütünle alakalı tanıtım yada satış,reçete ile satılan ilaçların satışı veya tanıtımı,tez yada öğrenci makalelerinin satışı yada tanıtımı kesinlikle yasaktır.";
$l['agreement_3'] = "Kayıt esnasında size kullanıcı adınızı seçme özgürlüğü verilmektedir.Tabi cinsellik ve-veya argo içeren isim-ler olmamak şartıyla. Ardından kayıt ettiğiniz hesap ile ilgili, şifrenizi yöneticiler dahil kimseye vermemeyi kabul etmiş sayılıyorsunuz (yasa ve güvenlik sebepleri). Bunun yanında başka bir kullanıcının hesabını kullanmamayı da kabul etmiş sayılıyorsunuz. Hesabınızın güvenliği için önerimiz karışık ve özel şifreler kullanmanızdır.";
$l['agreement_4'] = "Kayıt olduktan sonra profil alanlarınızı istediğiniz gibi düzenleyebilirsiniz. Fakat profil alanlarınızda kullandığınız her türlü illegal durumda yöneticiler sizi uyarmadan alanınızı düzenleyebilir veya silebilirler.<br /><br /><strong> Not:</strong> her konu ve yorumunuzun IP adresi kayıt altına alınmaktadır. Bunun nedeni ise IP adresinizin veya ISP adresinizin daha önceden banlanmış olabileceğidir. Bu durum sadece anlaşmanın önemli bir parçasını ihlal etmeniz ile oluşabilir.<br /><br /><strong>Ek Not:</strong> Foruma, Kayıt İşleminizden Sonra Bir Takım Bilgilerinizi Hatırlamak İçin Cookies-(çerez) Kullanılmaktadır. Bu Çerez Sizin Bilgisayarınızın Hard Diskine Yerleştirdiği Ufak Bir Text Dosyası&rdquo; İçin Kullanılmaktadır. Amacı ise Siteye Bir Sonraki Ziyarette Sizi Tanıması İçin Geçerli Bir Bilgidir. Bu Text Dosyası Bir Komut Dosyası Olmadığı Gibi, Virüs de Değildir,Kesinlikle Güvenlik Riskide Yoktur.";
$l['agreement_5'] = "Forum kuralları her zaman değiştirilebilir ve değiştikten sonra hemen geçerlidir. Bu kuralları takip etmeniz hem sizin hem forumun işleyişi açısından önemlidir.";
$l['registration'] = "Üye Kayıt Formu";
$l['required_fields'] = "Zorunlu Bilgiler";
$l['complex_password'] = "<acronym title=\"En Az {1} Karakter Uzunluğunda, Rakam ve Büyük / Küçük Harflerden Oluşan Karışık, Güvenli Şifre.\">Karmaşık</acronym> Şifre:";
$l['confirm_email'] = "E-Posta Tekrar:";
$l['optional_fields'] = "İsteğe Bağlı Bilgiler";
$l['website_url'] = "Web Site Adresi:";
$l['birthdate'] = "Doğum Tarihi:";
$l['additional_info'] = "İsteğe Bağlı Bilgiler:";
$l['required_info'] = "Zorunlu Bilgiler:";
$l['i_agree'] = "Üyelik Sözleşmesini Okudum ve Kabul Ediyorum »";
$l['account_details'] = "Hesap Detayları:";
$l['account_prefs'] = "Hesap Seçenekleri:";
$l['invisible_mode'] = "Kimler çevrimiçi listesinde görünmek istemiyorum?";
$l['allow_notices'] = "Yönetimden bilgi E-postaları almak istiyorum?";
$l['hide_email'] = "Tüm kullanıcılar bana ''E-posta'' gönderebilsin?";
$l['email_notify'] = "Yorum yazdığım konular takip listeme eklensin?";
$l['receive_pms'] = "Tüm kullanıcılar bana ''Özel Mesaj'' gönderebilsin?";
$l['pm_notice'] = "Yeni özel mesaj aldığım zaman bildirim gösterilsin?";
$l['email_notify_newpm'] = "Yeni özel mesaj aldığımda E-posta bildirimi gönderilsin?";
$l['time_offset'] = "Zaman Dilimi <acronym title=\"Greenwich Mean Time\">GMT</acronym> Ayarları:";
$l['time_offset_desc'] = "Forum saati otomatik olarak ayarlanmıştır. Eğer bulunduğunuz bölgeye göre saat farkı sorunu yaşıyorsanız, aşağıdaki size sunulan seçeneklerden bulunduğunuz bölgeye göre seçim yapabilirsiniz.";
$l['dst_correction'] = "<strong>Yaz / Kış Sezonu Saati <acronym title=\"Daylight Saving Time\">DST</acronym> Ayarları:</strong>";
$l['dst_correction_auto'] = "Otomatik Olarak DST Ayarlarını Algıla";
$l['dst_correction_enabled'] = "Her zaman DST Ayarlarını kullan";
$l['dst_correction_disabled'] = "Hiçbir Zaman DST Ayarlarını Kullanma";
$l['redirect_registered_coppa_activate'] = "Kayıt İçin Teşekkürler: {1}, {2}. Hesabınız Başarılı Bir Şekilde Oluşturulmuştur. Ancak Bu Hesabın Sahibi Olarak, 13 Yaş Altı Çocukların Korunması İçin, Ebeveyn Kontrol Formunun Doldurulup Tarafımıza Ulaştırılması Gerekiyor.<br /><br />Ebeveyn Kontrol Formuna <a rel=\"nofollow\" href=\"member.php?action=coppa_form\">Buradan Ulaşabilirsiniz</a>.<br /><br />Bu Form Doldurulup Bize Ulaştırıldığında Hesabınız Aktif Edilicektir.";
$l['coppa_compliance'] = "(Yaşını Doğrula)";
$l['coppa_desc'] = "<center><strong>(13 Yaş Altı Üye Kayıt Kontrolü)</strong><br />Lütfen, aşağıdaki formu kullanarak yaşınızı doğrulayın.</center><br />";
$l['hide_dob'] = "Doğum tarihiniz sadece yaşınızı doğrulamak için gereklidir.<br />Dilerseniz yaşınızı ve/veya doğum tarihinizi kayıt işlemini tamamladıktan sonra, profil ayarlarınızdan diğer üyelere gizleyebilirsiniz.";
$l['signature'] = "İmza:";
$l['continue_registration'] = "Yaşımı Doğrula »";
$l['birthdayprivacy'] = "Doğum Tarihi Gizlilik Seçenekleri:";
$l['birthdayprivacyall'] = "Doğum Tarihi ve Yaşımı Göster?";
$l['birthdayprivacynone'] = "Doğum Tarihi ve Yaşımı Gizle?";
$l['birthdayprivacyage'] = "Sadece Yaşımı Göster?";
$l['leave_this_field_empty'] = "Bu Alanı Boş Bırakın:";
$l['error_need_to_be_thirteen'] = "Üzünüz, fakat foruma kayıt olabilmeniz için 13 yaşından büyük olmanız gerekiyor.";
$l['coppa_registration'] = "(COPPA) - Ebeveyn Kontrolü Formu";
$l['coppa_form_instructions'] = "<strong>(COPPA) - Ebeveyn Kontrolü 13 Yaş Altı Üye Kayıt Formu</strong><br />Üyelik hesabınızın aktif olabilmesi için lütfen, aşağıdaki ''Ebeveyn Kontrol'' formunu doldurup yazıcıdan çıktısını alın ve bir kopyasını Fax veya E-Posta adresimize gönderiniz.";
$l['fax_number'] = "Fax Numaramız:";
$l['mailing_address'] = "E-Posta Adresimiz:";
$l['account_information'] = "<br />Hesap Bilgileriniz";
$l['parent_details'] = "Ebeveyn / Veli Detayları";
$l['full_name'] = "Ad Soyad:";
$l['relation'] = "Yakınlık Derecesi:";
$l['phone_no'] = "Tel No #:";
$l['coppa_parent_agreement'] = "Üsteki vermiş olduğum bilgilerin doğruluğunu kabul ediyorum.";

$l['coppa_agreement_1'] = "13 yaşının altındaki kullanıcıların, <strong>''{1}''</strong> sitesine kayıt olabilmeleri için aile bireyleri tarafından, aşağıdaki bağlantıda verilen, ''(COPPA) - Ebeveyn Kontrolü'' formunu doldurup tarafımıza göndermesi gerekiyor.";
$l['coppa_agreement_2'] = "Ebeveyn kontrol formuna <a rel=\"nofollow\" href=\"member.php?action=coppa_form\">Buradan</a> ulaşabilirsiniz.";
$l['coppa_agreement_3'] = "Eğer, isterseniz kayıt işlemine devam edebilirsiniz, ancak hesabınız aktif edilmeyecektir. Hesabınızın aktif olabilmesi için üsteki bağlantıda verilen <strong>''(COPPA) - Ebeveyn Kontrolü''</strong> formunun doldurulup tarafımıza gönderilmesi gereklidir.";

$l['error_invalid_birthday'] = 'Girdiğiniz doğum günü geçersiz. Geçerli bir doğum günü girin.';
$l['error_awaitingcoppa'] = "Giriş yapmak istediğiniz üyelik hesabı, hala ''Ebeveyn Kontrol'' formunun gönderilmesini Bekliyor.<br /><br />Ebeveyn kontrol formuna <a rel=\"nofollow\" href=\"member.php?action=coppa_form\">Buradan</a> ulaşabilirsiniz. Bu form doldurulup tarafımıza gönderilmediği sürece, Kullanıcı hesabınız aktif edilmeyecektir.";

$l['lang_select'] = "Dil Seçenekleri:";
$l['lang_select_desc'] = "Dilerseniz mevcut dil seçeneklerinden forum dilini değiştirebilirsiniz.";
$l['lang_select_default'] = "Varsayılan Dili Kullan";

$l['submit_registration'] = "Üyeliğimi Tamamla »";
$l['confirm_password'] = "Şifre Tekrar:";
$l['referrer'] = "Referans Bilgileri:";
$l['referrer_desc'] = "Forumumuzu size bir üyemiz tavsiye ettiyse lütfen, bu üyenin ismini (nick) aşağıdaki metin kutusuna giriniz. Veya boş bırakarak kayıt işlemine devam edebilirsiniz.";
$l['resend_activation'] = "Aktivasyon Kodunu Tekrar Yolla";
$l['request_activation'] = "Aktivasyon Kodu İsteği";
$l['ppp'] = "Sayfa Başına Yorumlar:";
$l['ppp_desc'] = "Sayfa Başına Gösterilecek Yorum Sayısını Seçmenizi Sağlar.";
$l['tpp'] = "Sayfa Başına Konular:";
$l['tpp_desc'] = "Sayfa Başına Gösterilecek Konu Sayısını Seçmenizi Sağlar.";
$l['reset_password'] = "Şifreyi Sıfırla";
$l['send_password'] = "Yeni Şifre Gönder!";
$l['registration_errors'] = "Kayıt İşleminiz Sırasında Altaki Hatalar Oluştu:";
$l['timeonline'] = "Aktiflik Süresi:";
$l['timeonline_hidden'] = "(Gizli)";
$l['registrations_disabled'] = "<center>Forumumuza üyelik alımlarını geçici bir süreliğine durdurduk.<br />Lütfen daha sonra tekrar deneyiniz.</center>";
$l['error_username_length'] = "Geçersiz bir kullanıcı adı girdiniz. Lütfen {1} ile {2} karakter arası bir kullanıcı adı giriniz.";
$l['error_stop_forum_spam_spammer'] = 'Üzgünüz, {1} veritabanımızda kayıtlı bilinen bir spam olarak algılandı. Eğer bunun bir hata olduğunu düşünüyorsanız lütfen, iletişim bölümünden forum yöneticisi ile irtibat kurunuz.';
$l['error_stop_forum_spam_fetching'] = 'Üzgünüz, hesabınızın bilinen bir spam olup olmadığını sorgulama sırasında veritabanında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.';

$l['none_registered'] = "Henüz Kayda Değer Aktivitesi Yok";
$l['not_specified'] = "Belirtilmemiş";
$l['membdayage'] = "- [Şu anda {1} yaşında]";
$l['mod_options'] = "Yönetici Araçları";
$l['edit_in_mcp'] = "Bu Kullancının Profilini Mod Panelinde Düzenle";
$l['ban_in_mcp'] = "Bu Kullanıcıyı Mod Panelinde Yasakla";
$l['purgespammer'] = "Bu Kullanıcıya Spam İşlemi Uygula";
$l['edit_usernotes'] = "Bu Kullanıcıya Yönetici Notu Ekle/Düzenle";
$l['no_usernotes'] = "Şu anda bu kullanıcıya ait kayıtlı hiçbir yönetici notu yok.";
$l['view_all_notes'] = "Tüm Notları Görüntüle";
$l['view_notes_for'] = "Notlarını Görüntüle: {1}";
$l['reputation'] = "Rep Puanı:";
$l['reputation_vote'] = "Rep Ver";
$l['reputation_details'] = "Ayrıntılar";
$l['already_logged_in'] = "<center><img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> <strong>Hatırlatma:</strong> Şu anda {1} nickli kullanıcı adı ile zaten giriş yapmışsınız..</center>";
$l['admin_edit_in_acp'] = "Bu Kullancının Profilini Admin Panelinde Düzenle";
$l['admin_ban_in_acp'] = "Bu Kullanıcıyı Admin Panelinde Yasakla";
$l['admin_options'] = "Admin Araçları";

$l['redirect_registered_activation'] = "Sayın {2}, {1} Forumlarına üye olup aramıza katıldığınız için teşekkür ederiz.<p>Kayıt işleminizi tamamlamak için üyelik hesabınızı aktif etmeniz gerekir.<br />Lütfen, Kayıt sırasında Kullandığınız E-posta adresinize gelen, ''Aktivasyon Mailini'' kontrol ediniz.<br />Aksi halde forumumuzda, konu açamaz, yorum yazamaz ve diğer aktivitelerden yararlanamazsınız..";
$l['redirect_emailupdated'] = "E-Posta Adresiniz Başarıyla Değiştirildi.<br />Şimdi Forum Ana Sayfasına Yönlendiriliyorsunuz...";
$l['redirect_accountactivated'] = "Üyeliğiniz Başarıyla Aktif Edilmiştir.<br />Şimdi Forum Ana Sayfasına Yönlendiriliyorsunuz...";
$l['redirect_accountactivated_admin'] = "E-Posta adresi doğrulanmıştır.<br />Fakat, bir yönetici tarafından onaylanması gerekiyor, bu süre içerisinde forumumuzdan tam olarak yararlanamayabilirsiniz.<br />Şimdi forum ana sayfasına yönlendiriliyorsunuz...";
$l['redirect_registered'] = "Sayın {2}, {1} Forumlarına üye olup aramıza katıldığınız için teşekkür ederiz.<br />Şimdi tekrar forum ana sayfasına yönlendiriliyorsunuz...";
$l['redirect_registered_admin_activate'] = "Sayın {2}, {1} Forumlarına üye olup aramıza katıldığınız için teşekkür ederiz.<br />Üyelik hesabınız, forum yöneticileri tarafından kontrol ediltikten sonra aktif edilicektir.<br />Aktif edilinceye kadar, forumumuzda yeni Konu ve Yorum gönderemeyebilirsiniz.";
$l['redirect_loggedout'] = "Çıkış işleminiz başarıyla gerçekleşmiştir.<br />Şimdi Tekrar Forum Ana Sayfasına Yönlendiriliyorsunuz...";
$l['redirect_alreadyloggedout'] = "Şu anda çıkış yapmış görünüyorsunuz veya henüz giriş yapmamışsınız.<br />Şimdi Tekrar Forum Ana Sayfasına Yönlendiriliyorsunuz.";
$l['redirect_lostpwsent'] = "Teşekkürler, E-Posta adresinize şifre değişikliği ile ilgili gerekli tüm bilgiler gönderilmiştir.<br /><br />Şimdi forum ana sayfasına yönlendiriliyorsunuz...";
$l['redirect_activationresent'] = "Aktivasyon E-maili tekrar gönderilmiştir. Lütfen E-postanızı Kontrol Ediniz.";
$l['redirect_passwordreset'] = "Teşekkürler, Şifreniz Yenilendi. Gerekli bilgiler E-posta adresinize gönderilmiştir.";
$l['redirect_memberrated'] = "Üye Puanı başarıyla eklenmiştir.";
$l['redirect_registered_passwordsent'] = "Rastgele bir şifre oluşturularak, E-posta adresinize gönderilmiştir. Foruma giriş yapabilmek için lütfen E-postanızı kontrol ediniz.";
$l['redirect_validated'] = "Teşekkürler, hesabınız onaylanmıştır.<br />Şimdi tekrar forum ana sayfasına yönlendiriliyorsunuz.";

$l['error_activated_by_admin'] = "Aktivasyon işlemi forum yöneticileri tarafından onaylandığı için tekrar, aktivasyon maili isteği gönderilemiyor.";
$l['error_alreadyregistered'] = "Üzgünüz, fakat sistemimiz bu forumda kayıtlı olduğunuzu saptamıştır. Ayrıca sitemize ''Multi Üyelik'' yasaktır.";
$l['error_alreadyregisteredtime'] = "Üyelik kaydınız gerçekleştirilemiyor. Çünkü sistemimiz {2} saat içerisinde aynı (IP Adresi) üzerinden yapılan {1} tane kayıt olduğunu saptamıştır. <br />Lütfen daha sonra tekrar deneyiniz..";
$l['error_badlostpwcode'] = "Geçersiz Bir Parola Sıfırlama Kodu Girdiniz. Lütfen Size Gönderilen E-postayı Tekrar Kontrol Ediniz Veya Size Yardım Etmeleri İçin Forum Yöneticileriyle İletişime Geçiniz.";
$l['error_badactivationcode'] = "Girmiş Olduğunuz Aktivasyon Kodu Geçersizdir. Yeni Bir Aktivasyon Talebi İçin <a rel=\"nofollow\" href=\"member.php?action=resendactivation\">Buraya</a> Tıklayınız.";
$l['error_alreadyactivated'] = "Üyelik hesabınız aktif görünüyor ve E-posta doğrulaması yapmanıza gerek yoktur.";
$l['error_alreadyvalidated'] = "E-posta adresi zaten doğrulanmış.";
$l['error_nothreadurl'] = "Mesajınızda Konu Adresi Kullanılamaz. Lütfen Yapmak İstediğiniz Amaç İçin (Bu Konuyu Arkadaşıma Gönder)'i Kullanınız.";
$l['error_bannedusername'] = "Yasaklı Bir Kullanıcı Adı Girdiniz. Lütfen Başka Bir Kullanıcı Adı Giriniz.";
$l['error_notloggedout'] = "Kullanıcı (ID) Kimliğiniz Çıkış Yapabilmeniz İçin Doğrulanamadı. Kötü Niyetli Bir (Javascript) Çıkış Yapmanızı Engeliyor Olabilir. Eğer Çıkış Yapmak İstiyorsanız Üsteki Menüden (Çıkış Yap) Butonuna Tıklayınız.";
$l['error_regimageinvalid'] = "Girilen Güvenlik Kodu Yanlıştır. Lütfen Resimde Görünen Kodları Doğru Bir Şekilde Giriniz. (Büyük / Küçük Harf Duyarlıdır)";
$l['error_regimagerequired'] = "Girilen Güvenlik Kodu Yanlıştır.<br /> Lütfen Resimde Görünen Kodları Doğru Bir Şekilde Giriniz. (Büyük / Küçük Harf Duyarlıdır)";
$l['error_spam_deny'] = "Üyelik kaydınız sistem tarafımdan spam olarak algılanmış olabilir. Eğer bunun bir hata olduğunu düşünüyorsanız lütfen, iletişim bölümünden yönetici ile irtibat kurunuz.";
$l['error_spam_deny_time'] = "Üyelik kaydınız sistem tarafımdan spam olarak algılanmış olabilir. {1} saniye önce kayıt girişiminde bulunmuşsunuz, tekrar kayıt işlemini yapmak için {2} saniye daha bekleyiniz. Eğer bunun bir hata olduğunu düşünüyorsanız lütfen, iletişim bölümünden yönetici ile irtibat kurunuz.";

$l['js_validator_no_username'] = "Lütfen Bir Kullanıcı Adı Giriniz.";
$l['js_validator_invalid_email'] = "Lütfen Geçerli Bir E-posta Adresi Giriniz.";
$l['js_validator_email_match'] = "Lütfen Aynı E-posta Adresinizi Tekrar Giriniz.";
$l['js_validator_no_image_text'] = "Lütfen Üsteki Güvenlik Kodunu Giriniz.";
$l['js_validator_no_security_question'] = "Yukarıdaki Soruya Cevap Girmeniz Gerekiyor.";
$l['js_validator_password_matches'] = "Girmiş Olduğunuz Şifreler Uyuşmuyor. Lütfen Şifrenizin Doğruluğunu Kontrol Ediniz.";
$l['js_validator_password_complexity'] = "Lütfen Karmaşık Semboller İçeren Bir Şifre Giriniz.";
$l['js_validator_password_length'] = "Lütfen Şifrenizi En az {1} Karakter veya Daha Uzun Giriniz.";
$l['js_validator_not_empty'] = "Her Hangi Bir Seçim Yapmadınız, Lütfen Seçiminizi Yapınız.";
$l['js_validator_checking_username'] = "Kullanıcı Adının Alınabilirliği Kontrol Ediliyor.";
$l['js_validator_username_length'] = "Kullanıcı Adı En az {1} ve {2} Karakter Arası Olmalıdır.";
$l['js_validator_checking_referrer'] = "Kullanıcı Adı Denetleniyor.";
$l['js_validator_captcha_valid'] = "Güvenlik Kodunun Doğruluğu Denetleniyor.";

$l['security_question'] = "Güvenlik Sorusu:";
$l['question_note'] = "Lütfen, aşağıdaki metin kutusuna sorunun cevabını giriniz.<br />Bu işlem otomatik spam kayıtları engellemek için kullanılmaktadır.";
$l['error_question_wrong'] = "Güvenlik sorusu için girilen cevap yanlış. Lütfen tekrar deneyiniz.";

$l['subscription_method'] = "<strong>Konu Takip Seçenekleri:</strong><br />Aşağıdaki seçeneklerden yorum yazdığınız konuların otomatik bildirim ve takibini yönetebilirsiniz.";
$l['no_auto_subscribe'] = "Takip Etmek İstemiyorum?";
$l['no_subscribe'] = "Bildirim Almak İstemiyorum?";
$l['no_email_subscribe'] = "E-posta Bildirimi İstemiyorum?";
$l['instant_email_subscribe'] = "Anında E-posta Bildirimi Gönderilsin?";
$l['instant_pm_subscribe'] = "Anında ÖM Bildirimi Gönderilsin?";

$l['remove_from_buddy_list'] = "Arkadaşlarımdan Çıkar";
$l['add_to_buddy_list'] = "Arkadaş Olarak Ekle";
$l['remove_from_ignore_list'] = "Engeli Kaldır";
$l['add_to_ignore_list'] = "Engelle";
$l['report_user'] = "Şikayet Et";

$l['newregistration_subject'] = "{1} Yeni Kayıt Mevcut";
$l['newregistration_message'] = "{1},

Toplam: {2}, Yönetici aktivasyonu bekleyen yeni bir kullanıcı kaydı mevcut.

Kullanıcı Adı: {3}

Teşekkürler,
{2} - Yönetimi";
